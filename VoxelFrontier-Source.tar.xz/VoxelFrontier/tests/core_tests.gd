extends SceneTree

const INVENTORY_SCRIPT = preload("res://scripts/inventory.gd")
const WORLD_SCRIPT = preload("res://scripts/voxel_world.gd")
const SAVE_SCRIPT = preload("res://scripts/save_manager.gd")

var failures := 0
var assertions := 0

func _initialize() -> void:
	call_deferred("_run")

func _check(condition: bool, description: String) -> void:
	assertions += 1
	if condition:
		print("PASS: ", description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func _run() -> void:
	await _test_inventory()
	await _test_world_and_save()
	print("Core tests: %d assertions, %d failure(s)." % [assertions, failures])
	quit(1 if failures > 0 else 0)

func _test_inventory() -> void:
	var inventory: FrontierInventory = INVENTORY_SCRIPT.new()
	root.add_child(inventory)
	await process_frame

	_check(inventory.add_item("coal", 70) == 0, "Adding a valid amount fills stacks without leftovers")
	_check(inventory.count_item("coal") == 70, "Stack overflow creates a second stack instead of losing items")
	_check(int(inventory.slots[0].get("count", 0)) == 64 and int(inventory.slots[1].get("count", 0)) == 6,
		"Stacks respect the item's maximum stack size")
	_check(inventory.remove_item("coal", 65), "Removing an amount consumes across stacks")
	_check(inventory.count_item("coal") == 5, "Removal leaves the exact remaining quantity")

	inventory.restore_slots([])
	inventory.add_item("log", 1)
	_check(inventory.craft(0), "Valid plank recipe can be crafted")
	_check(inventory.count_item("log") == 0 and inventory.count_item("planks") == 4,
		"Craft consumes inputs and adds the recipe result")
	var before := inventory.export_slots()
	_check(not inventory.craft(3), "A recipe without sufficient ingredients is rejected")
	_check(inventory.export_slots() == before, "Rejected craft leaves inventory unchanged")

	# A full inventory with a full plank stack must roll back input consumption.
	inventory.restore_slots([])
	for item_id in ItemCatalog.ITEMS.keys():
		inventory.add_item(String(item_id), 64)
		var empty_count := 0
		for slot in inventory.slots:
			if typeof(slot) != TYPE_DICTIONARY or slot.is_empty():
				empty_count += 1
		if empty_count == 0:
			break
	_check(inventory.slots.size() == inventory.CAPACITY, "Inventory has a fixed number of slots")
	if inventory.count_item("log") > 0 and inventory.count_item("planks") > 0:
		var logs_before := inventory.count_item("log")
		var planks_before := inventory.count_item("planks")
		_check(not inventory.craft(0), "Crafting fails when there is no capacity for output")
		_check(inventory.count_item("log") == logs_before and inventory.count_item("planks") == planks_before,
			"Failed output insertion rolls back all recipe ingredients")
	else:
		_check(false, "Full-inventory rollback fixture contains logs and planks")

	inventory.restore_slots([
		{"id": "unknown_debug_item", "count": 99},
		{"id": "wooden_pickaxe", "count": 99, "durability": 100000},
		{"id": "berry", "count": 99}
	])
	_check(inventory.count_item("unknown_debug_item") == 0, "Unknown saved item IDs are discarded")
	_check(inventory.count_item("wooden_pickaxe") == 1, "Saved non-stackable tools are capped to one item")
	_check(inventory.count_item("berry") == 32, "Corrupt saved stack counts are clamped to catalog limits")
	root.remove_child(inventory)
	inventory.free()

func _test_world_and_save() -> void:
	var world: VoxelWorld = WORLD_SCRIPT.new()
	world.render_distance = 0
	root.add_child(world)
	await world.initialize_world(314159, {})
	_check(world.visible_chunk_count() == 1, "World initialization creates the requested single test chunk")
	_check(world.chunk_at_world(Vector3i(-1, 10, -1)) == Vector2i(-1, -1),
		"Negative world coordinates map to the correct negative chunk")
	_check(world.surface_height(11, -7) >= 5 and world.surface_height(11, -7) < VoxelChunk.HEIGHT,
		"Generated terrain height stays inside world bounds")

	var surface_y := world.surface_height(0, 0)
	var surface_pos := Vector3i(0, surface_y, 0)
	var original_block := world.get_block_global(surface_pos)
	var expected_drop := BlockCatalog.drop_for(original_block)
	var actual_drop := world.break_block(surface_pos)
	_check(not actual_drop.is_empty() and actual_drop == expected_drop, "Breaking a surface block returns its configured drop")
	_check(world.get_block_global(surface_pos) == BlockCatalog.AIR, "Breaking a block updates voxel data immediately")
	_check(world.export_changes().has("0,%d,0" % surface_y), "Voxel edits are recorded under stable world coordinates")

	var seed_check: VoxelWorld = WORLD_SCRIPT.new()
	seed_check.seed_value = 314159
	seed_check._setup_noise()
	_check(seed_check.surface_height(11, -7) == world.surface_height(11, -7),
		"Identical seed reproduces terrain heights at the same coordinates")
	_check(seed_check.biome_at(11, -7) == world.biome_at(11, -7),
		"Identical seed reproduces biome classification")
	seed_check.free()

	var payload := {
		"seed": 314159,
		"creative": false,
		"changes": world.export_changes(),
		"player_position": [0.5, float(surface_y + 2), 0.5],
		"health": 100.0,
		"hunger": 85.0,
		"inventory": [{"id": "berry", "count": 8}],
		"time_of_day": 0.32
	}
	_check(SAVE_SCRIPT.save_world(payload), "SaveManager writes a world payload")
	var loaded: Dictionary = SAVE_SCRIPT.load_world()
	_check(int(loaded.get("seed", 0)) == 314159, "SaveManager restores the world seed")
	_check(loaded.get("changes", {}).get("0,%d,0" % surface_y, -1) == BlockCatalog.AIR,
		"SaveManager preserves a block-removal edit")
	_check(loaded.get("inventory", []).size() == 1, "SaveManager stores inventory data")

	# Simulate an interrupted write: primary JSON is broken, the previous valid
	# snapshot remains in .bak and must be recoverable without crashing the game.
	var save_path := ProjectSettings.globalize_path("user://worlds/main_world.json")
	var backup_path := save_path + ".bak"
	var backup_file := FileAccess.open(backup_path, FileAccess.WRITE)
	_check(backup_file != null, "Backup fixture can be written")
	if backup_file != null:
		var backup_payload := payload.duplicate(true)
		backup_payload["save_version"] = 1
		backup_payload["changes"] = {"0,%d,0" % surface_y: BlockCatalog.AIR, "1,1,1": BlockCatalog.STONE, "bad-coordinate": 99, "0,999,0": 1, "2,2,2": "not-a-block"}
		backup_file.store_string(JSON.stringify(backup_payload))
		backup_file.close()
	var broken_file := FileAccess.open(save_path, FileAccess.WRITE)
	_check(broken_file != null, "Primary save can be replaced with a corrupt fixture")
	if broken_file != null:
		broken_file.store_string("{truncated-json")
		broken_file.close()
	var recovered: Dictionary = SAVE_SCRIPT.load_world()
	_check(int(recovered.get("seed", 0)) == 314159, "Corrupt primary save recovers from the last valid backup")
	_check(recovered.get("changes", {}).size() == 2, "Loaded change records reject malformed coordinates, heights and block IDs")
	DirAccess.remove_absolute(save_path)
	DirAccess.remove_absolute(backup_path)

	var restored: VoxelWorld = WORLD_SCRIPT.new()
	restored.render_distance = 0
	root.add_child(restored)
	await restored.initialize_world(314159, loaded.get("changes", {}))
	_check(restored.get_block_global(surface_pos) == BlockCatalog.AIR,
		"Reinitializing the world applies saved block edits over generated terrain")
	root.remove_child(restored)
	restored.free()
	root.remove_child(world)
	world.free()
