extends RefCounted
class_name SaveManager

const SAVE_PATH := "user://worlds/main_world.json"
const SAVE_VERSION := 1
const WORLD_HEIGHT := 48
const MAX_BLOCK_ID := 14

static func load_world() -> Dictionary:
	# A previous write may have completed the backup rename and crashed before
	# installing the new file. Prefer the primary save, then recover the backup.
	var primary := _read_world_file(SAVE_PATH)
	if not primary.is_empty():
		return primary
	return _read_world_file(SAVE_PATH + ".bak")

static func _read_world_file(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}
	var raw := file.get_as_text()
	file.close()
	var parsed: Variant = JSON.parse_string(raw)
	if typeof(parsed) != TYPE_DICTIONARY:
		return {}
	var data: Dictionary = parsed
	var version_value: Variant = data.get("save_version", 0)
	var seed_value: Variant = data.get("seed")
	if typeof(version_value) not in [TYPE_INT, TYPE_FLOAT]:
		return {}
	var version := int(version_value)
	if version < 1 or version > SAVE_VERSION:
		return {}
	if typeof(seed_value) not in [TYPE_INT, TYPE_FLOAT]:
		return {}
	if typeof(data.get("changes")) != TYPE_DICTIONARY:
		return {}

	# Saved JSON is user-controlled data. Sanitize entries before they reach
	# typed gameplay APIs, instead of trusting dictionary keys and values.
	var clean_changes: Dictionary = {}
	var raw_changes: Dictionary = data["changes"]
	for raw_key in raw_changes.keys():
		var key := String(raw_key)
		var parts := key.split(",")
		if parts.size() != 3:
			continue
		if not parts[0].is_valid_int() or not parts[1].is_valid_int() or not parts[2].is_valid_int():
			continue
		var y := int(parts[1])
		var block_value: Variant = raw_changes[raw_key]
		if y <= 0 or y >= WORLD_HEIGHT:
			continue
		if typeof(block_value) not in [TYPE_INT, TYPE_FLOAT]:
			continue
		var block_id := int(block_value)
		if block_id < 0 or block_id > MAX_BLOCK_ID:
			continue
		clean_changes[key] = block_id
	data["changes"] = clean_changes

	if typeof(data.get("inventory", [])) != TYPE_ARRAY:
		data["inventory"] = []
	var position_value: Variant = data.get("player_position", [])
	if typeof(position_value) != TYPE_ARRAY:
		data.erase("player_position")
	else:
		var position: Array = position_value
		var valid_position := position.size() >= 3
		for i in range(mini(3, position.size())):
			if typeof(position[i]) not in [TYPE_INT, TYPE_FLOAT]:
				valid_position = false
				break
		if not valid_position:
			data.erase("player_position")
	var view_value: Variant = data.get("view", [])
	if typeof(view_value) != TYPE_ARRAY:
		data.erase("view")
	else:
		var view: Array = view_value
		if view.size() < 2 or typeof(view[0]) not in [TYPE_INT, TYPE_FLOAT] or typeof(view[1]) not in [TYPE_INT, TYPE_FLOAT]:
			data.erase("view")
	if typeof(data.get("creative", false)) != TYPE_BOOL:
		data["creative"] = false
	if typeof(data.get("time_of_day", 0.32)) not in [TYPE_INT, TYPE_FLOAT]:
		data["time_of_day"] = 0.32
	else:
		data["time_of_day"] = clampf(float(data["time_of_day"]), 0.0, 1.0)
	return data

static func save_world(data: Dictionary) -> bool:
	var payload := data.duplicate(true)
	payload["save_version"] = SAVE_VERSION
	payload["saved_at_unix"] = int(Time.get_unix_time_from_system())
	var path := ProjectSettings.globalize_path(SAVE_PATH)
	var directory := path.get_base_dir()
	var dir_error := DirAccess.make_dir_recursive_absolute(directory)
	if dir_error != OK and dir_error != ERR_ALREADY_EXISTS:
		return false
	var temporary := path + ".tmp"
	var backup := path + ".bak"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(payload))
	file.flush()
	var write_error := file.get_error()
	file.close()
	if write_error != OK:
		DirAccess.remove_absolute(temporary)
		return false
	if FileAccess.file_exists(backup):
		DirAccess.remove_absolute(backup)
	if FileAccess.file_exists(path):
		var backup_error := DirAccess.rename_absolute(path, backup)
		if backup_error != OK:
			DirAccess.remove_absolute(temporary)
			return false
	var replace_error := DirAccess.rename_absolute(temporary, path)
	if replace_error != OK:
		if FileAccess.file_exists(backup):
			DirAccess.rename_absolute(backup, path)
		return false
	return true
