extends CharacterBody3D
class_name FrontierPlayer

signal health_changed(health: float, hunger: float)
signal died
signal action_failed(message: String)

const WALK_SPEED := 5.2
const RUN_SPEED := 7.3
const JUMP_VELOCITY := 7.2
const LOOK_SENSITIVITY := 0.0026
var look_sensitivity := LOOK_SENSITIVITY

var world: VoxelWorld
var inventory: FrontierInventory
var move_vector := Vector2.ZERO
var camera: Camera3D
var camera_pivot: Node3D
var ray: RayCast3D
var health := 100.0
var hunger := 100.0
var creative_mode := false
var _jump_pending := false
var _yaw := 0.0
var _pitch := 0.0
var _invulnerability := 0.0

func _ready() -> void:
	name = "Player"
	collision_layer = 2
	collision_mask = 1
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.78
	var shape_node := CollisionShape3D.new()
	shape_node.name = "BodyCollider"
	shape_node.shape = capsule
	shape_node.position.y = 0.89
	add_child(shape_node)

	camera_pivot = Node3D.new()
	camera_pivot.name = "CameraPivot"
	camera_pivot.position.y = 1.58
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.name = "FirstPersonCamera"
	camera.current = true
	camera.fov = 78.0
	camera_pivot.add_child(camera)
	ray = RayCast3D.new()
	ray.name = "InteractionRay"
	ray.target_position = Vector3(0, 0, -5.5)
	ray.collision_mask = 5
	ray.enabled = true
	camera.add_child(ray)

func _physics_process(delta: float) -> void:
	if _invulnerability > 0.0:
		_invulnerability -= delta
	var keyboard := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): keyboard.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): keyboard.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): keyboard.y += 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): keyboard.y -= 1.0
	var input_vector := move_vector if move_vector.length() > 0.08 else keyboard
	input_vector = input_vector.limit_length(1.0)
	var direction := (global_transform.basis.x * input_vector.x + -global_transform.basis.z * input_vector.y).normalized()
	var mobile_sprint := move_vector.length() >= 0.96
	var speed := RUN_SPEED if Input.is_key_pressed(KEY_SHIFT) or mobile_sprint else WALK_SPEED
	velocity.x = move_toward(velocity.x, direction.x * speed, 22.0 * delta)
	velocity.z = move_toward(velocity.z, direction.z * speed, 22.0 * delta)
	if not is_on_floor():
		velocity.y -= float(ProjectSettings.get_setting("physics/3d/default_gravity")) * delta
	elif _jump_pending or Input.is_key_pressed(KEY_SPACE):
		velocity.y = JUMP_VELOCITY
		_jump_pending = false
	move_and_slide()

func set_move_vector(value: Vector2) -> void:
	move_vector = value.limit_length(1.0)

func apply_look_delta(delta: Vector2) -> void:
	_yaw -= delta.x * look_sensitivity
	_pitch = clampf(_pitch - delta.y * look_sensitivity, -1.42, 1.42)
	rotation.y = _yaw
	camera_pivot.rotation.x = _pitch

func request_jump() -> void:
	_jump_pending = true

func set_look_sensitivity(value: float) -> void:
	look_sensitivity = LOOK_SENSITIVITY * clampf(value, 0.5, 2.5)

func break_target() -> void:
	if world == null or ray == null:
		return
	ray.force_raycast_update()
	if not ray.is_colliding():
		return
	var collider := ray.get_collider()
	if collider is FrontierCreature:
		(collider as FrontierCreature).receive_hit(self)
		if inventory != null:
			inventory.damage_selected_tool(1)
		return
	var hit_position := ray.get_collision_point()
	var normal := ray.get_collision_normal()
	var block_position := Vector3i(floori(hit_position.x - normal.x * 0.01), floori(hit_position.y - normal.y * 0.01), floori(hit_position.z - normal.z * 0.01))
	var block_id := world.get_block_global(block_position)
	if block_id == BlockCatalog.AIR:
		return
	var drop_id := BlockCatalog.drop_for(block_id)
	if not creative_mode and (inventory == null or not inventory.can_add_item(drop_id, 1)):
		action_failed.emit("Инвентарь заполнен")
		return
	var result := world.break_block(block_position)
	if result.is_empty():
		return
	if not creative_mode:
		inventory.add_item(result, 1)
		inventory.damage_selected_tool(1)

func place_target() -> void:
	if world == null or inventory == null or ray == null:
		return
	ray.force_raycast_update()
	if not ray.is_colliding() or ray.get_collider() is FrontierCreature:
		return
	var item_stack := inventory.selected_item()
	var item_id := String(item_stack.get("id", ""))
	var block_id := ItemCatalog.block_for_item(item_id)
	if block_id == BlockCatalog.AIR:
		action_failed.emit("Выбери блок на панели")
		return
	var hit_position := ray.get_collision_point()
	var normal := ray.get_collision_normal()
	var place_position := Vector3i(floori(hit_position.x + normal.x * 0.01), floori(hit_position.y + normal.y * 0.01), floori(hit_position.z + normal.z * 0.01))
	if _intersects_player(place_position):
		return
	if not creative_mode and not inventory.remove_item(item_id, 1):
		return
	if not world.place_block(place_position, block_id):
		if not creative_mode:
			inventory.add_item(item_id, 1)
		action_failed.emit("Нельзя поставить блок здесь")

func _intersects_player(block_position: Vector3i) -> bool:
	var p := global_position
	if block_position.y < floori(p.y) or block_position.y > floori(p.y + 1.72):
		return false
	return absf((float(block_position.x) + 0.5) - p.x) < 0.42 and absf((float(block_position.z) + 0.5) - p.z) < 0.42

func eat_selected() -> void:
	if inventory == null:
		return
	var restored := inventory.use_selected_food()
	if restored > 0:
		hunger = minf(100.0, hunger + float(restored))
		health_changed.emit(health, hunger)
	else:
		action_failed.emit("В выбранном слоте нет еды")

func take_damage(amount: float) -> void:
	if creative_mode or _invulnerability > 0.0:
		return
	health = maxf(0.0, health - amount)
	_invulnerability = 0.65
	health_changed.emit(health, hunger)
	if health <= 0.0:
		died.emit()

func apply_survival_tick(delta: float) -> void:
	if creative_mode:
		return
	hunger = maxf(0.0, hunger - delta * 0.085)
	if hunger <= 0.0:
		health = maxf(0.0, health - delta * 0.35)
	elif hunger > 75.0 and health < 100.0:
		health = minf(100.0, health + delta * 0.08)
	health_changed.emit(health, hunger)
	if health <= 0.0:
		died.emit()

func restore_status(saved_health: float, saved_hunger: float) -> void:
	health = clampf(saved_health, 1.0, 100.0)
	hunger = clampf(saved_hunger, 0.0, 100.0)
	health_changed.emit(health, hunger)

func restore_view(saved_yaw: float, saved_pitch: float) -> void:
	_yaw = saved_yaw
	_pitch = clampf(saved_pitch, -1.42, 1.42)
	rotation.y = _yaw
	camera_pivot.rotation.x = _pitch

func get_view_rotation() -> Vector2:
	return Vector2(_yaw, _pitch)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		apply_look_delta(event.relative)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode >= KEY_1 and event.keycode <= KEY_8 and inventory != null:
			inventory.set_selected_slot(event.keycode - KEY_1)
		elif event.keycode == KEY_SPACE:
			request_jump()
