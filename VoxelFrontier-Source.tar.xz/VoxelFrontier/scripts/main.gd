extends Node3D

const WORLD_SCRIPT = preload("res://scripts/voxel_world.gd")
const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const INVENTORY_SCRIPT = preload("res://scripts/inventory.gd")
const HUD_SCRIPT = preload("res://scripts/touch_hud.gd")
const CREATURE_SCRIPT = preload("res://scripts/creature.gd")

var world: VoxelWorld
var player: FrontierPlayer
var inventory: FrontierInventory
var hud: FrontierHUD
var world_environment: WorldEnvironment
var sun: DirectionalLight3D
var day_time := 0.32
var auto_save_clock := 0.0
var survival_clock := 0.0
var current_seed := 0
var current_creative := false
var _world_ready := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_environment()
	_setup_hud()
	var saved := SaveManager.load_world()
	hud.set_continue_available(not saved.is_empty())
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		_save_current_world(false)

func _setup_environment() -> void:
	world_environment = WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.10, 0.24, 0.36)
	sky_material.sky_horizon_color = Color(0.63, 0.73, 0.73)
	sky_material.ground_bottom_color = Color(0.07, 0.09, 0.09)
	sky_material.ground_horizon_color = Color(0.40, 0.48, 0.44)
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.53, 0.61, 0.63)
	environment.ambient_light_energy = 0.72
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_environment.environment = environment
	add_child(world_environment)

	sun = DirectionalLight3D.new()
	sun.name = "SunAndMoon"
	sun.rotation = Vector3(deg_to_rad(-48.0), deg_to_rad(-32.0), deg_to_rad(-18.0))
	sun.light_color = Color(1.0, 0.91, 0.76)
	sun.light_energy = 1.15
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 90.0
	add_child(sun)

func _setup_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "HUDLayer"
	layer.layer = 10
	add_child(layer)
	hud = HUD_SCRIPT.new()
	hud.name = "TouchHUD"
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.process_mode = Node.PROCESS_MODE_ALWAYS
	layer.add_child(hud)
	hud.start_requested.connect(_on_start_requested)
	hud.continue_requested.connect(_on_continue_requested)
	hud.action_requested.connect(_on_hud_action)
	hud.movement_changed.connect(_on_movement_changed)
	hud.look_changed.connect(_on_look_changed)
	hud.hotbar_selected.connect(_on_hotbar_selected)
	hud.craft_requested.connect(_on_craft_requested)

func _process(delta: float) -> void:
	if sun != null and _world_ready and hud != null and hud.mode == "game":
		day_time = fposmod(day_time + delta / 720.0, 1.0)
		var sun_height := sin(day_time * TAU - PI * 0.5)
		sun.rotation = Vector3(deg_to_rad(-sun_height * 105.0), deg_to_rad(-32.0), deg_to_rad(-18.0))
		sun.light_energy = lerpf(0.06, 1.15, clampf(sun_height * 0.5 + 0.5, 0.0, 1.0))
		if world_environment != null and world_environment.environment != null:
			world_environment.environment.ambient_light_energy = lerpf(0.16, 0.78, clampf(sun_height * 0.5 + 0.5, 0.0, 1.0))
	if not _world_ready or player == null or hud == null:
		return
	if hud.mode == "game":
		survival_clock += delta
		if survival_clock >= 1.0:
			player.apply_survival_tick(survival_clock)
			survival_clock = 0.0
		auto_save_clock += delta
		if auto_save_clock >= 25.0:
			auto_save_clock = 0.0
			_save_current_world(false)

func _on_start_requested(creative: bool) -> void:
	current_seed = randi()
	current_creative = creative
	await _load_world_state({}, creative)

func _on_continue_requested() -> void:
	var saved := SaveManager.load_world()
	if saved.is_empty():
		hud.notify("Сохранение не найдено или повреждено")
		hud.set_continue_available(false)
		return
	current_seed = int(saved.get("seed", 0))
	current_creative = bool(saved.get("creative", false))
	await _load_world_state(saved, current_creative)

func _load_world_state(saved: Dictionary, creative: bool) -> void:
	hud.set_mode("loading")
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	await get_tree().process_frame
	await _clear_world_nodes()

	world = WORLD_SCRIPT.new()
	world.name = "VoxelWorld"
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(world)
	var saved_changes: Dictionary = saved.get("changes", {}) if not saved.is_empty() else {}
	await world.initialize_world(current_seed, saved_changes)

	inventory = INVENTORY_SCRIPT.new()
	inventory.name = "PlayerInventory"
	inventory.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(inventory)
	if not saved.is_empty():
		var saved_slots: Array = saved.get("inventory", [])
		inventory.restore_slots(saved_slots)
	else:
		_seed_starting_inventory(creative)

	player = PLAYER_SCRIPT.new()
	player.name = "Player"
	player.process_mode = Node.PROCESS_MODE_PAUSABLE
	player.world = world
	player.inventory = inventory
	player.creative_mode = creative
	add_child(player)
	world.player_reference = player
	_spawn_creatures()
	if not saved.is_empty():
		var p: Array = saved.get("player_position", [0.0, float(world.surface_height(0, 0) + 3), 0.0])
		if p.size() >= 3:
			player.global_position = Vector3(float(p[0]), float(p[1]), float(p[2]))
		player.restore_status(float(saved.get("health", 100.0)), float(saved.get("hunger", 100.0)))
		var view: Array = saved.get("view", [0.0, 0.0])
		if view.size() >= 2:
			player.restore_view(float(view[0]), float(view[1]))
		day_time = float(saved.get("time_of_day", 0.32))
	else:
		player.global_position = Vector3(0.5, float(world.surface_height(0, 0) + 2), 0.5)
		player.restore_status(100.0, 100.0)
	inventory.changed.connect(_sync_inventory_hud)
	player.health_changed.connect(_on_player_health_changed)
	player.died.connect(_on_player_died)
	player.action_failed.connect(hud.notify)
	_sync_inventory_hud()
	hud.set_world_seed(current_seed, creative)
	hud.set_status(player.health, player.hunger)
	hud.set_continue_available(true)
	hud.set_mode("game")
	_world_ready = true
	auto_save_clock = 0.0
	survival_clock = 0.0
	if not OS.has_feature("android"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _spawn_creatures() -> void:
	if world == null or player == null:
		return
	var spawn_data: Array[Dictionary] = [
		{"species": "field_hare", "x": 7, "z": 5},
		{"species": "trail_fox", "x": -9, "z": 8},
		{"species": "moss_golem", "x": 17, "z": -13},
		{"species": "night_stalker", "x": -18, "z": -16}
	]
	for entry in spawn_data:
		var creature: FrontierCreature = CREATURE_SCRIPT.new()
		creature.process_mode = Node.PROCESS_MODE_PAUSABLE
		creature.configure(String(entry["species"]), world, player)
		world.add_child(creature)
		var x := int(entry["x"])
		var z := int(entry["z"])
		creature.global_position = Vector3(float(x) + 0.5, float(world.surface_height(x, z)) + 1.25, float(z) + 0.5)

func _seed_starting_inventory(creative: bool) -> void:
	if creative:
		for item_id in ["grass_block", "dirt", "stone", "sand", "log", "leaves", "iron_ore", "snow_block", "clay", "moss", "planks", "bricks", "torch"]:
			inventory.add_item(item_id, 64)
	inventory.add_item("berry", 8)
	inventory.add_item("log", 4)
	inventory.add_item("dirt", 16)
	inventory.add_item("stone", 8)
	inventory.add_item("stick", 4)

func _clear_world_nodes() -> void:
	_world_ready = false
	if player != null and is_instance_valid(player):
		player.queue_free()
	if inventory != null and is_instance_valid(inventory):
		inventory.queue_free()
	if world != null and is_instance_valid(world):
		world.queue_free()
	player = null
	inventory = null
	world = null
	await get_tree().process_frame

func _on_movement_changed(value: Vector2) -> void:
	if player != null and is_instance_valid(player):
		player.set_move_vector(value)

func _on_look_changed(value: Vector2) -> void:
	if player != null and is_instance_valid(player):
		player.apply_look_delta(value)

func _on_hotbar_selected(index: int) -> void:
	if inventory != null:
		inventory.set_selected_slot(index)

func _on_craft_requested(index: int) -> void:
	if inventory == null:
		return
	if inventory.craft(index):
		hud.notify("Создано: %s" % String(ItemCatalog.RECIPES[index]["name"]))
	else:
		hud.notify("Не хватает ресурсов или нет места")

func _on_hud_action(action: String) -> void:
	match action:
		"jump":
			if player != null: player.request_jump()
		"break":
			if player != null: player.break_target()
		"place":
			if player != null: player.place_target()
		"eat":
			if player != null: player.eat_selected()
		"pause": _enter_pause()
		"resume": _resume_game()
		"save":
			var success := _save_current_world(true)
			hud.notify("Мир сохранён" if success else "Не удалось сохранить мир")
		"save_menu":
			_save_current_world(false)
			get_tree().paused = false
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			await _clear_world_nodes()
			hud.set_mode("menu")
			hud.set_continue_available(not SaveManager.load_world().is_empty())
		"inventory":
			hud.set_mode("inventory")
			get_tree().paused = true
		"close_inventory":
			get_tree().paused = false
			hud.set_mode("game")
		"respawn":
			if player != null:
				player.global_position = Vector3(0.5, float(world.surface_height(0, 0) + 2), 0.5)
				player.velocity = Vector3.ZERO
				player.restore_status(100.0, 65.0)
				get_tree().paused = false
				hud.set_mode("game")
				if not OS.has_feature("android"): Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _enter_pause() -> void:
	if not _world_ready:
		return
	_save_current_world(false)
	get_tree().paused = true
	hud.set_mode("pause")
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _resume_game() -> void:
	get_tree().paused = false
	hud.set_mode("game")
	if not OS.has_feature("android"): Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _save_current_world(show_feedback: bool) -> bool:
	if not _world_ready or world == null or player == null or inventory == null:
		return false
	var position := player.global_position
	var view := player.get_view_rotation()
	var payload: Dictionary = {
		"seed": current_seed,
		"creative": current_creative,
		"changes": world.export_changes(),
		"player_position": [position.x, position.y, position.z],
		"health": player.health,
		"hunger": player.hunger,
		"view": [view.x, view.y],
		"inventory": inventory.export_slots(),
		"time_of_day": day_time
	}
	var saved := SaveManager.save_world(payload)
	if saved:
		hud.set_continue_available(true)
	if show_feedback:
		hud.notify("Мир сохранён" if saved else "Ошибка сохранения")
	return saved

func _sync_inventory_hud() -> void:
	if hud != null and inventory != null:
		hud.update_inventory(inventory.export_slots(), inventory.selected_slot)

func _on_player_health_changed(value: float, food: float) -> void:
	if hud != null:
		hud.set_status(value, food)

func _on_player_died() -> void:
	if hud != null and hud.mode != "dead":
		_save_current_world(false)
		get_tree().paused = true
		hud.set_mode("dead")
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if hud.mode == "game":
				_enter_pause()
			elif hud.mode == "inventory":
				_on_hud_action("close_inventory")
			elif hud.mode == "pause":
				_resume_game()
		elif event.keycode == KEY_E:
			if hud.mode == "game":
				_on_hud_action("inventory")
			elif hud.mode == "inventory":
				_on_hud_action("close_inventory")
		elif event.keycode == KEY_F and hud.mode == "game":
			if player != null: player.eat_selected()
