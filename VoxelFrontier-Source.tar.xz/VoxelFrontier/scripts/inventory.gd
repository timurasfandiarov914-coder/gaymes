extends Node
class_name FrontierInventory

signal changed

const CAPACITY := 24
const HOTBAR_SIZE := 8
var slots: Array = []
var selected_slot := 0

func _ready() -> void:
	if slots.is_empty():
		for i in range(CAPACITY):
			slots.append({})

func set_selected_slot(index: int) -> void:
	selected_slot = clampi(index, 0, HOTBAR_SIZE - 1)
	changed.emit()

func selected_item() -> Dictionary:
	if selected_slot < 0 or selected_slot >= slots.size():
		return {}
	var value: Variant = slots[selected_slot]
	return value if typeof(value) == TYPE_DICTIONARY else {}

func count_item(item_id: String) -> int:
	var total := 0
	for stack in slots:
		if typeof(stack) == TYPE_DICTIONARY and String(stack.get("id", "")) == item_id:
			total += int(stack.get("count", 0))
	return total

func can_add_item(item_id: String, amount: int = 1) -> bool:
	if amount <= 0 or not ItemCatalog.ITEMS.has(item_id):
		return false
	var remaining := amount
	var max_stack := int(ItemCatalog.ITEMS[item_id].get("max_stack", 64))
	for stack in slots:
		if typeof(stack) == TYPE_DICTIONARY and String(stack.get("id", "")) == item_id:
			remaining -= max(0, max_stack - int(stack.get("count", 0)))
	for stack in slots:
		if typeof(stack) != TYPE_DICTIONARY or stack.is_empty():
			remaining -= max_stack
		if remaining <= 0:
			return true
	return remaining <= 0

func add_item(item_id: String, amount: int = 1) -> int:
	if amount <= 0 or not ItemCatalog.ITEMS.has(item_id):
		return amount
	var remaining := amount
	var max_stack := int(ItemCatalog.ITEMS[item_id].get("max_stack", 64))
	for i in range(slots.size()):
		var stack: Dictionary = slots[i] if typeof(slots[i]) == TYPE_DICTIONARY else {}
		if String(stack.get("id", "")) != item_id:
			continue
		var room := max_stack - int(stack.get("count", 0))
		if room <= 0:
			continue
		var moved := min(room, remaining)
		stack["count"] = int(stack.get("count", 0)) + moved
		slots[i] = stack
		remaining -= moved
		if remaining <= 0:
			changed.emit()
			return 0
	for i in range(slots.size()):
		if typeof(slots[i]) == TYPE_DICTIONARY and not slots[i].is_empty():
			continue
		var moved := min(max_stack, remaining)
		slots[i] = {"id": item_id, "count": moved}
		remaining -= moved
		if remaining <= 0:
			changed.emit()
			return 0
	changed.emit()
	return remaining

func has_items(requirements: Dictionary) -> bool:
	for item_id in requirements.keys():
		if count_item(String(item_id)) < int(requirements[item_id]):
			return false
	return true

func remove_item(item_id: String, amount: int = 1) -> bool:
	if amount <= 0 or count_item(item_id) < amount:
		return false
	var remaining := amount
	for i in range(slots.size()):
		if typeof(slots[i]) != TYPE_DICTIONARY or String(slots[i].get("id", "")) != item_id:
			continue
		var stack: Dictionary = slots[i]
		var moved := min(int(stack.get("count", 0)), remaining)
		stack["count"] = int(stack.get("count", 0)) - moved
		remaining -= moved
		slots[i] = {} if int(stack["count"]) <= 0 else stack
		if remaining <= 0:
			changed.emit()
			return true
	return false

func craft(recipe_index: int) -> bool:
	if recipe_index < 0 or recipe_index >= ItemCatalog.RECIPES.size():
		return false
	var recipe: Dictionary = ItemCatalog.RECIPES[recipe_index]
	var requirements: Dictionary = recipe["inputs"]
	if not has_items(requirements):
		return false
	var backup := slots.duplicate(true)
	for item_id in requirements.keys():
		if not remove_item(String(item_id), int(requirements[item_id])):
			slots = backup
			changed.emit()
			return false
	var leftover := add_item(String(recipe["output"]), int(recipe["count"]))
	if leftover > 0:
		slots = backup
		changed.emit()
		return false
	changed.emit()
	return true

func use_selected_food() -> int:
	var stack := selected_item()
	var item_id := String(stack.get("id", ""))
	var item: Dictionary = ItemCatalog.get_item(item_id)
	var food := int(item.get("food", 0))
	if food <= 0 or not remove_item(item_id, 1):
		return 0
	return food

func damage_selected_tool(amount: int = 1) -> void:
	var stack := selected_item()
	if stack.is_empty():
		return
	var item: Dictionary = ItemCatalog.get_item(String(stack.get("id", "")))
	if not item.has("durability"):
		return
	var durability := int(stack.get("durability", item.get("durability", 0))) - amount
	if durability <= 0:
		slots[selected_slot] = {}
	else:
		stack["durability"] = durability
		slots[selected_slot] = stack
	changed.emit()

func export_slots() -> Array:
	return slots.duplicate(true)

func restore_slots(saved: Array) -> void:
	# Treat saves as untrusted input: keep fixed slot positions and clamp each stack to catalog limits.
	slots.clear()
	for i in range(CAPACITY):
		var value: Variant = saved[i] if i < saved.size() else {}
		if typeof(value) != TYPE_DICTIONARY:
			slots.append({})
			continue
		var item_id := String(value.get("id", ""))
		var item_count := int(value.get("count", 0))
		if not ItemCatalog.ITEMS.has(item_id) or item_count <= 0:
			slots.append({})
			continue
		var item_data: Dictionary = ItemCatalog.ITEMS[item_id]
		var max_stack := int(item_data.get("max_stack", 64))
		var restored := {"id": item_id, "count": mini(item_count, max_stack)}
		if value.has("durability") and item_data.has("durability"):
			restored["durability"] = clampi(int(value["durability"]), 1, int(item_data["durability"]))
		slots.append(restored)
	selected_slot = 0
	changed.emit()
