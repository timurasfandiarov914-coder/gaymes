extends Control
class_name FrontierHUD

signal start_requested(creative: bool)
signal continue_requested
signal action_requested(action: String)
signal movement_changed(value: Vector2)
signal look_changed(value: Vector2)
signal hotbar_selected(index: int)
signal craft_requested(index: int)

var mode := "menu"
var can_continue := false
var creative_mode := false
var seed_value := 0
var health := 100.0
var hunger := 100.0
var slots_snapshot: Array = []
var selected_slot := 0
var notification_text := ""
var _notification_left := 0.0
var _touch_roles: Dictionary = {}
var _move_finger := -1
var _move_origin := Vector2.ZERO
var _move_current := Vector2.ZERO
var _look_finger := -1

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(true)
	for i in range(24):
		slots_snapshot.append({})

func set_mode(next_mode: String) -> void:
	mode = next_mode
	_move_finger = -1
	_look_finger = -1
	_move_origin = Vector2.ZERO
	_move_current = Vector2.ZERO
	movement_changed.emit(Vector2.ZERO)
	queue_redraw()

func set_continue_available(value: bool) -> void:
	can_continue = value
	queue_redraw()

func set_world_seed(value: int, creative: bool) -> void:
	seed_value = value
	creative_mode = creative
	queue_redraw()

func set_status(next_health: float, next_hunger: float) -> void:
	health = clampf(next_health, 0.0, 100.0)
	hunger = clampf(next_hunger, 0.0, 100.0)
	queue_redraw()

func update_inventory(snapshot: Array, selected: int) -> void:
	slots_snapshot = snapshot.duplicate(true)
	selected_slot = selected
	queue_redraw()

func notify(message: String) -> void:
	notification_text = message
	_notification_left = 2.4
	queue_redraw()

func _process(delta: float) -> void:
	if _notification_left > 0.0:
		_notification_left -= delta
		if _notification_left <= 0.0:
			notification_text = ""
			queue_redraw()

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_handle_press(event.index, event.position)
		else:
			_handle_release(event.index)
	elif event is InputEventScreenDrag:
		_handle_drag(event.index, event.position, event.relative)
	elif event is InputEventMouseButton and event.pressed:
		_handle_mouse_press(event.button_index, event.position)
	elif event is InputEventMouseButton and not event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT and mode in ["menu", "pause", "inventory", "dead"]:
			get_viewport().set_input_as_handled()

func _handle_press(index: int, position: Vector2) -> void:
	if mode == "menu":
		_handle_menu_tap(position)
		get_viewport().set_input_as_handled()
		return
	if mode == "loading":
		return
	if mode == "pause":
		_handle_pause_tap(position)
		get_viewport().set_input_as_handled()
		return
	if mode == "dead":
		_handle_dead_tap(position)
		get_viewport().set_input_as_handled()
		return
	if mode == "inventory":
		_handle_inventory_tap(position)
		get_viewport().set_input_as_handled()
		return
	if mode != "game":
		return
	if _pause_rect().has_point(position):
		action_requested.emit("pause")
		get_viewport().set_input_as_handled()
		return
	if _hotbar_rect().has_point(position):
		var index_in_bar := _hotbar_index_at(position)
		if index_in_bar >= 0:
			hotbar_selected.emit(index_in_bar)
		get_viewport().set_input_as_handled()
		return
	if _control_rect("jump").has_point(position):
		action_requested.emit("jump")
		get_viewport().set_input_as_handled()
		return
	if _control_rect("break").has_point(position):
		action_requested.emit("break")
		get_viewport().set_input_as_handled()
		return
	if _control_rect("place").has_point(position):
		action_requested.emit("place")
		get_viewport().set_input_as_handled()
		return
	if _control_rect("inventory").has_point(position):
		action_requested.emit("inventory")
		get_viewport().set_input_as_handled()
		return
	if _control_rect("eat").has_point(position):
		action_requested.emit("eat")
		get_viewport().set_input_as_handled()
		return
	if position.x < size.x * 0.34 and position.y > size.y * 0.51:
		_move_finger = index
		_move_origin = position
		_move_current = position
		_touch_roles[index] = "move"
		_update_move_vector()
		queue_redraw()
	else:
		_look_finger = index
		_touch_roles[index] = "look"

func _handle_release(index: int) -> void:
	var role := String(_touch_roles.get(index, ""))
	_touch_roles.erase(index)
	if role == "move" and _move_finger == index:
		_move_finger = -1
		_move_origin = Vector2.ZERO
		_move_current = Vector2.ZERO
		movement_changed.emit(Vector2.ZERO)
		queue_redraw()
	elif role == "look" and _look_finger == index:
		_look_finger = -1

func _handle_drag(index: int, position: Vector2, relative: Vector2) -> void:
	var role := String(_touch_roles.get(index, ""))
	if role == "move" and _move_finger == index:
		_move_current = position
		_update_move_vector()
		queue_redraw()
	elif role == "look" and _look_finger == index and mode == "game":
		look_changed.emit(relative)

func _update_move_vector() -> void:
	var radius := minf(size.x, size.y) * 0.085
	if radius <= 1.0:
		return
	var delta := _move_current - _move_origin
	var vector := Vector2(delta.x, -delta.y) / radius
	movement_changed.emit(vector.limit_length(1.0))

func _handle_mouse_press(button: int, position: Vector2) -> void:
	if button != MOUSE_BUTTON_LEFT and button != MOUSE_BUTTON_RIGHT:
		return
	if mode == "menu":
		_handle_menu_tap(position)
		get_viewport().set_input_as_handled()
	elif mode == "pause":
		_handle_pause_tap(position)
		get_viewport().set_input_as_handled()
	elif mode == "dead":
		_handle_dead_tap(position)
		get_viewport().set_input_as_handled()
	elif mode == "inventory":
		_handle_inventory_tap(position)
		get_viewport().set_input_as_handled()
	elif mode == "game":
		if button == MOUSE_BUTTON_LEFT:
			action_requested.emit("break")
		else:
			action_requested.emit("place")
		get_viewport().set_input_as_handled()

func _handle_menu_tap(position: Vector2) -> void:
	for i in range(3):
		if _menu_button_rect(i).has_point(position):
			match i:
				0: start_requested.emit(false)
				1: start_requested.emit(true)
				2:
					if can_continue:
						continue_requested.emit()
			return

func _handle_pause_tap(position: Vector2) -> void:
	for i in range(3):
		if _pause_menu_rect(i).has_point(position):
			match i:
				0: action_requested.emit("resume")
				1: action_requested.emit("save_menu")
				2: action_requested.emit("save")
			return

func _handle_dead_tap(position: Vector2) -> void:
	if _dead_button_rect(0).has_point(position):
		action_requested.emit("respawn")
	elif _dead_button_rect(1).has_point(position):
		action_requested.emit("save_menu")

func _handle_inventory_tap(position: Vector2) -> void:
	var panel := _inventory_panel_rect()
	if not panel.has_point(position):
		action_requested.emit("close_inventory")
		return
	var row_height := 37.0
	var first_y := panel.position.y + 235.0
	for i in range(ItemCatalog.RECIPES.size()):
		var row := Rect2(panel.position.x + 20.0, first_y + float(i) * row_height, panel.size.x - 40.0, row_height - 3.0)
		if row.has_point(position):
			craft_requested.emit(i)
			return

func _menu_button_rect(index: int) -> Rect2:
	var width := minf(size.x * 0.72, 390.0)
	var height := 48.0
	return Rect2(Vector2((size.x - width) * 0.5, size.y * 0.42 + index * 61.0), Vector2(width, height))

func _pause_menu_rect(index: int) -> Rect2:
	var width := minf(size.x * 0.72, 390.0)
	return Rect2(Vector2((size.x - width) * 0.5, size.y * 0.40 + index * 61.0), Vector2(width, 48.0))

func _dead_button_rect(index: int) -> Rect2:
	var width := minf(size.x * 0.72, 390.0)
	return Rect2(Vector2((size.x - width) * 0.5, size.y * 0.52 + index * 61.0), Vector2(width, 48.0))

func _pause_rect() -> Rect2:
	return Rect2(Vector2(12, 12), Vector2(112, 48))

func _control_rect(which: String) -> Rect2:
	var h := size.y
	var w := size.x
	match which:
		"jump": return Rect2(Vector2(w * 0.84, h * 0.72), Vector2(w * 0.12, h * 0.16))
		"break": return Rect2(Vector2(w * 0.68, h * 0.55), Vector2(w * 0.12, h * 0.15))
		"place": return Rect2(Vector2(w * 0.85, h * 0.55), Vector2(w * 0.12, h * 0.15))
		"inventory": return Rect2(Vector2(w * 0.80, h * 0.38), Vector2(w * 0.13, h * 0.14))
		"eat": return Rect2(Vector2(w * 0.68, h * 0.76), Vector2(w * 0.12, h * 0.14))
	return Rect2()

func _hotbar_rect() -> Rect2:
	var slot_size := clampf(size.x * 0.047, 35.0, 54.0)
	var gap := 5.0
	var total := slot_size * 8.0 + gap * 7.0
	return Rect2(Vector2((size.x - total) * 0.5, size.y * 0.875), Vector2(total, slot_size + 8.0))

func _hotbar_index_at(position: Vector2) -> int:
	var rect := _hotbar_rect()
	var slot_size := clampf(size.x * 0.047, 35.0, 54.0)
	var gap := 5.0
	for i in range(8):
		var slot_rect := Rect2(Vector2(rect.position.x + i * (slot_size + gap), rect.position.y), Vector2(slot_size, slot_size + 4.0))
		if slot_rect.has_point(position):
			return i
	return -1

func _inventory_panel_rect() -> Rect2:
	var width := minf(size.x * 0.88, 640.0)
	var height := minf(size.y * 0.83, 540.0)
	return Rect2(Vector2((size.x - width) * 0.5, (size.y - height) * 0.5), Vector2(width, height))

func _draw() -> void:
	if mode == "menu":
		_draw_menu()
	elif mode == "loading":
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.055, 0.078, 0.095))
		_draw_center_text("GENERATING WORLD", size.y * 0.51, 26, Color(0.88, 0.91, 0.88))
		_draw_center_text("Building terrain and chunk meshes", size.y * 0.57, 15, Color(0.55, 0.63, 0.65))
	else:
		_draw_game_hud()
		if mode == "inventory":
			_draw_inventory()
		elif mode == "pause":
			_draw_pause()
		elif mode == "dead":
			_draw_dead()
	if not notification_text.is_empty() and _notification_left > 0.0:
		var rect := Rect2(Vector2(size.x * 0.28, size.y * 0.22), Vector2(size.x * 0.44, 42))
		draw_rect(rect, Color(0.06, 0.08, 0.09, 0.88), true)
		draw_string(ThemeDB.fallback_font, rect.position + Vector2(0, 26), notification_text, HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, 17, Color(0.95, 0.91, 0.77))

func _draw_menu() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.055, 0.078, 0.095))
	var accent := Color(0.44, 0.72, 0.50)
	draw_rect(Rect2(Vector2(size.x * 0.12, size.y * 0.16), Vector2(size.x * 0.76, 3)), accent)
	_draw_center_text("VOXEL FRONTIER", size.y * 0.27, 38, Color(0.94, 0.95, 0.91))
	_draw_center_text("A WORLD THAT YOU CAN CHANGE", size.y * 0.33, 14, Color(0.53, 0.65, 0.64))
	var labels := ["НОВЫЙ МИР · ВЫЖИВАНИЕ", "ТВОРЧЕСКИЙ РЕЖИМ", "ПРОДОЛЖИТЬ"]
	for i in range(3):
		var rect := _menu_button_rect(i)
		var enabled := i != 2 or can_continue
		draw_rect(rect, Color(0.15, 0.20, 0.21) if enabled else Color(0.10, 0.13, 0.14), true)
		draw_rect(rect, accent if i == 0 and enabled else Color(0.31, 0.38, 0.38), false, 1.0)
		draw_string(ThemeDB.fallback_font, Vector2(rect.position.x, rect.position.y + 30), labels[i], HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, 16, Color(0.91, 0.94, 0.89) if enabled else Color(0.37, 0.43, 0.44))
	_draw_center_text("OFFLINE FIRST  /  PROCEDURAL WORLD", size.y * 0.91, 12, Color(0.38, 0.47, 0.49))

func _draw_game_hud() -> void:
	var w := size.x
	var h := size.y
	draw_rect(_pause_rect(), Color(0.05, 0.08, 0.09, 0.74), true)
	draw_string(ThemeDB.fallback_font, Vector2(24, 42), "Ⅱ  PAUSE", HORIZONTAL_ALIGNMENT_LEFT, 100.0, 15, Color(0.92, 0.94, 0.90))
	var health_rect := Rect2(Vector2(18, 72), Vector2(180, 12))
	var hunger_rect := Rect2(Vector2(18, 93), Vector2(180, 9))
	draw_rect(health_rect, Color(0.10, 0.15, 0.14, 0.75), true)
	draw_rect(Rect2(health_rect.position, Vector2(health_rect.size.x * health / 100.0, health_rect.size.y)), Color(0.67, 0.28, 0.25), true)
	draw_rect(hunger_rect, Color(0.10, 0.15, 0.14, 0.75), true)
	draw_rect(Rect2(hunger_rect.position, Vector2(hunger_rect.size.x * hunger / 100.0, hunger_rect.size.y)), Color(0.81, 0.60, 0.27), true)
	draw_string(ThemeDB.fallback_font, Vector2(210, 83), "HP %d" % roundi(health), HORIZONTAL_ALIGNMENT_LEFT, 90.0, 13, Color(0.92, 0.89, 0.84))
	draw_string(ThemeDB.fallback_font, Vector2(210, 101), "FOOD %d" % roundi(hunger), HORIZONTAL_ALIGNMENT_LEFT, 90.0, 12, Color(0.92, 0.89, 0.84))
	draw_string(ThemeDB.fallback_font, Vector2(w - 220, 30), "SEED  %d" % seed_value, HORIZONTAL_ALIGNMENT_RIGHT, 200.0, 13, Color(0.75, 0.82, 0.79))
	if creative_mode:
		draw_string(ThemeDB.fallback_font, Vector2(w - 220, 50), "CREATIVE", HORIZONTAL_ALIGNMENT_RIGHT, 200.0, 12, Color(0.50, 0.78, 0.62))
	else:
		draw_string(ThemeDB.fallback_font, Vector2(w - 220, 50), "SURVIVAL", HORIZONTAL_ALIGNMENT_RIGHT, 200.0, 12, Color(0.78, 0.70, 0.49))
	# The centered reticle stays clear of touch controls.
	draw_line(Vector2(w * 0.5 - 6, h * 0.5), Vector2(w * 0.5 - 2, h * 0.5), Color(0.96, 0.96, 0.90), 2.0)
	draw_line(Vector2(w * 0.5 + 2, h * 0.5), Vector2(w * 0.5 + 6, h * 0.5), Color(0.96, 0.96, 0.90), 2.0)
	draw_line(Vector2(w * 0.5, h * 0.5 - 6), Vector2(w * 0.5, h * 0.5 - 2), Color(0.96, 0.96, 0.90), 2.0)
	draw_line(Vector2(w * 0.5, h * 0.5 + 2), Vector2(w * 0.5, h * 0.5 + 6), Color(0.96, 0.96, 0.90), 2.0)
	_draw_hotbar()
	_draw_touch_controls()

func _draw_hotbar() -> void:
	var rect := _hotbar_rect()
	var slot_size := clampf(size.x * 0.047, 35.0, 54.0)
	var gap := 5.0
	for i in range(8):
		var slot := Rect2(Vector2(rect.position.x + i * (slot_size + gap), rect.position.y), Vector2(slot_size, slot_size + 4.0))
		draw_rect(slot, Color(0.07, 0.10, 0.11, 0.88), true)
		draw_rect(slot, Color(0.49, 0.74, 0.55) if i == selected_slot else Color(0.37, 0.44, 0.44), false, 2.0 if i == selected_slot else 1.0)
		var stack: Dictionary = slots_snapshot[i] if i < slots_snapshot.size() and typeof(slots_snapshot[i]) == TYPE_DICTIONARY else {}
		if not stack.is_empty():
			var short := ItemCatalog.short_name(String(stack.get("id", "")))
			draw_string(ThemeDB.fallback_font, Vector2(slot.position.x, slot.position.y + slot.size.y * 0.53), short, HORIZONTAL_ALIGNMENT_CENTER, slot.size.x, 11, Color(0.88, 0.92, 0.86))
			draw_string(ThemeDB.fallback_font, Vector2(slot.position.x, slot.position.y + slot.size.y - 3), str(stack.get("count", 0)), HORIZONTAL_ALIGNMENT_RIGHT, slot.size.x - 3, 10, Color(0.93, 0.92, 0.83))
		draw_string(ThemeDB.fallback_font, Vector2(slot.position.x, slot.position.y - 3), str(i + 1), HORIZONTAL_ALIGNMENT_LEFT, 18, 10, Color(0.60, 0.67, 0.65))

func _draw_touch_controls() -> void:
	var h := size.y
	var w := size.x
	var radius := minf(w, h) * 0.085
	var joy_base := Vector2(w * 0.15, h * 0.78)
	if _move_finger >= 0:
		joy_base = _move_origin
	draw_string(ThemeDB.fallback_font, Vector2(w * 0.055, h * 0.90), "PUSH TO RUN", HORIZONTAL_ALIGNMENT_LEFT, 125.0, 11, Color(0.59, 0.68, 0.64, 0.86))
	draw_circle(joy_base, radius, Color(0.08, 0.12, 0.13, 0.36))
	draw_circle(joy_base, radius, Color(0.54, 0.64, 0.61, 0.75), false, 2.0)
	var joy_delta := Vector2.ZERO
	if _move_finger >= 0:
		joy_delta = (_move_current - _move_origin).limit_length(radius * 0.74)
	draw_circle(joy_base + joy_delta, radius * 0.36, Color(0.70, 0.82, 0.73, 0.55))
	_draw_control("break", "MINE")
	_draw_control("place", "PLACE")
	_draw_control("jump", "JUMP")
	_draw_control("inventory", "BAG")
	_draw_control("eat", "EAT")

func _draw_control(which: String, label_text: String) -> void:
	var rect := _control_rect(which)
	var center := rect.get_center()
	var radius := minf(rect.size.x, rect.size.y) * 0.34
	draw_circle(center, radius, Color(0.08, 0.12, 0.13, 0.48))
	draw_circle(center, radius, Color(0.60, 0.70, 0.66, 0.73), false, 1.6)
	draw_string(ThemeDB.fallback_font, Vector2(center.x - radius, center.y + 5), label_text, HORIZONTAL_ALIGNMENT_CENTER, radius * 2.0, 12, Color(0.94, 0.95, 0.89))

func _draw_inventory() -> void:
	var panel := _inventory_panel_rect()
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.015, 0.025, 0.028, 0.72), true)
	draw_rect(panel, Color(0.075, 0.105, 0.11, 0.98), true)
	draw_rect(panel, Color(0.42, 0.61, 0.49), false, 2.0)
	draw_string(ThemeDB.fallback_font, panel.position + Vector2(22, 34), "INVENTORY  /  CRAFTING", HORIZONTAL_ALIGNMENT_LEFT, panel.size.x - 44, 20, Color(0.92, 0.94, 0.88))
	draw_string(ThemeDB.fallback_font, panel.position + Vector2(22, 60), "Tap a recipe to craft. Ingredients are consumed only when the output fits.", HORIZONTAL_ALIGNMENT_LEFT, panel.size.x - 44, 12, Color(0.56, 0.65, 0.63))
	var grid_y := panel.position.y + 76.0
	var cell_w := (panel.size.x - 44.0) / 6.0
	for i in range(24):
		var col := i % 6
		var row := int(i / 6)
		var cell := Rect2(Vector2(panel.position.x + 22 + col * cell_w, grid_y + row * 36), Vector2(cell_w - 4, 32))
		draw_rect(cell, Color(0.12, 0.16, 0.16), true)
		draw_rect(cell, Color(0.28, 0.35, 0.34), false, 1.0)
		var stack: Dictionary = slots_snapshot[i] if i < slots_snapshot.size() and typeof(slots_snapshot[i]) == TYPE_DICTIONARY else {}
		if not stack.is_empty():
			draw_string(ThemeDB.fallback_font, cell.position + Vector2(4, 20), ItemCatalog.short_name(String(stack.get("id", ""))), HORIZONTAL_ALIGNMENT_LEFT, cell.size.x - 8, 10, Color(0.91, 0.93, 0.87))
			draw_string(ThemeDB.fallback_font, cell.position + Vector2(0, 30), str(stack.get("count", 0)), HORIZONTAL_ALIGNMENT_RIGHT, cell.size.x - 4, 9, Color(0.77, 0.82, 0.76))
	var recipe_y := panel.position.y + 235.0
	for i in range(ItemCatalog.RECIPES.size()):
		var recipe: Dictionary = ItemCatalog.RECIPES[i]
		var row_rect := Rect2(Vector2(panel.position.x + 20, recipe_y + i * 37.0), Vector2(panel.size.x - 40, 34))
		draw_rect(row_rect, Color(0.13, 0.18, 0.18), true)
		draw_rect(row_rect, Color(0.25, 0.34, 0.32), false, 1.0)
		var inputs_text := ""
		for item_id in recipe["inputs"].keys():
			if not inputs_text.is_empty(): inputs_text += "  +  "
			inputs_text += "%s ×%d" % [ItemCatalog.item_name(String(item_id)), int(recipe["inputs"][item_id])]
		var output_text := "%s  ×%d" % [ItemCatalog.item_name(String(recipe["output"])), int(recipe["count"])]
		draw_string(ThemeDB.fallback_font, row_rect.position + Vector2(8, 14), String(recipe["name"]), HORIZONTAL_ALIGNMENT_LEFT, row_rect.size.x * 0.35, 11, Color(0.90, 0.93, 0.87))
		draw_string(ThemeDB.fallback_font, row_rect.position + Vector2(row_rect.size.x * 0.36, 14), inputs_text, HORIZONTAL_ALIGNMENT_LEFT, row_rect.size.x * 0.43, 10, Color(0.60, 0.70, 0.67))
		draw_string(ThemeDB.fallback_font, row_rect.position + Vector2(row_rect.size.x * 0.80, 14), output_text, HORIZONTAL_ALIGNMENT_RIGHT, row_rect.size.x * 0.18, 10, Color(0.71, 0.84, 0.67))
	draw_string(ThemeDB.fallback_font, panel.position + Vector2(22, panel.size.y - 14), "Tap outside to close  ·  E / Esc also closes", HORIZONTAL_ALIGNMENT_LEFT, panel.size.x - 44, 11, Color(0.55, 0.64, 0.62))

func _draw_pause() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.015, 0.025, 0.028, 0.78), true)
	_draw_center_text("PAUSED", size.y * 0.29, 32, Color(0.93, 0.94, 0.89))
	var labels := ["ПРОДОЛЖИТЬ", "СОХРАНИТЬ И В МЕНЮ", "СОХРАНИТЬ МИР"]
	for i in range(3):
		var rect := _pause_menu_rect(i)
		draw_rect(rect, Color(0.12, 0.17, 0.17), true)
		draw_rect(rect, Color(0.38, 0.55, 0.45), false, 1.0)
		draw_string(ThemeDB.fallback_font, Vector2(rect.position.x, rect.position.y + 30), labels[i], HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, 15, Color(0.91, 0.94, 0.88))

func _draw_dead() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.06, 0.025, 0.025, 0.82), true)
	_draw_center_text("YOU FELL IN THE FRONTIER", size.y * 0.38, 27, Color(0.94, 0.85, 0.80))
	var labels := ["ВОЗРОДИТЬСЯ", "СОХРАНИТЬ И В МЕНЮ"]
	for i in range(2):
		var rect := _dead_button_rect(i)
		draw_rect(rect, Color(0.17, 0.11, 0.10), true)
		draw_rect(rect, Color(0.62, 0.37, 0.31), false, 1.0)
		draw_string(ThemeDB.fallback_font, Vector2(rect.position.x, rect.position.y + 30), labels[i], HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, 15, Color(0.93, 0.89, 0.85))

func _draw_center_text(text_value: String, y: float, font_size: int, color: Color) -> void:
	draw_string(ThemeDB.fallback_font, Vector2(0, y), text_value, HORIZONTAL_ALIGNMENT_CENTER, size.x, font_size, color)
