extends Node3D
class_name VoxelChunk

const SIZE := 16
const HEIGHT := 48
const BLOCK_COUNT := SIZE * SIZE * HEIGHT
const FACE_DEFS := [
	{"normal": Vector3i(1, 0, 0), "corners": [Vector3(1, 0, 0), Vector3(1, 1, 0), Vector3(1, 1, 1), Vector3(1, 0, 1)]},
	{"normal": Vector3i(-1, 0, 0), "corners": [Vector3(0, 0, 1), Vector3(0, 1, 1), Vector3(0, 1, 0), Vector3(0, 0, 0)]},
	{"normal": Vector3i(0, 1, 0), "corners": [Vector3(0, 1, 0), Vector3(0, 1, 1), Vector3(1, 1, 1), Vector3(1, 1, 0)]},
	{"normal": Vector3i(0, -1, 0), "corners": [Vector3(0, 0, 1), Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(1, 0, 1)]},
	{"normal": Vector3i(0, 0, 1), "corners": [Vector3(1, 0, 1), Vector3(1, 1, 1), Vector3(0, 1, 1), Vector3(0, 0, 1)]},
	{"normal": Vector3i(0, 0, -1), "corners": [Vector3(0, 0, 0), Vector3(0, 1, 0), Vector3(1, 1, 0), Vector3(1, 0, 0)]}
]

var chunk_coords := Vector2i.ZERO
var data := PackedByteArray()
var mesh_instance: MeshInstance3D
var collision_body: StaticBody3D
var _surface_material: StandardMaterial3D

func _init() -> void:
	data.resize(BLOCK_COUNT)
	_surface_material = StandardMaterial3D.new()
	_surface_material.vertex_color_use_as_albedo = true
	_surface_material.roughness = 1.0
	_surface_material.cull_mode = BaseMaterial3D.CULL_BACK

func get_local(x: int, y: int, z: int) -> int:
	if x < 0 or x >= SIZE or y < 0 or y >= HEIGHT or z < 0 or z >= SIZE:
		return BlockCatalog.AIR
	return int(data[_index(x, y, z)])

func set_local(x: int, y: int, z: int, block_id: int) -> void:
	if x < 0 or x >= SIZE or y < 0 or y >= HEIGHT or z < 0 or z >= SIZE:
		return
	data[_index(x, y, z)] = block_id

func _index(x: int, y: int, z: int) -> int:
	return x + SIZE * (z + SIZE * y)

func rebuild_mesh(world: VoxelWorld) -> void:
	if mesh_instance != null and is_instance_valid(mesh_instance):
		remove_child(mesh_instance)
		mesh_instance.queue_free()
		mesh_instance = null
	if collision_body != null and is_instance_valid(collision_body):
		remove_child(collision_body)
		collision_body.queue_free()
		collision_body = null

	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors := PackedColorArray()
	var indices := PackedInt32Array()
	var vertex_index := 0

	for y in range(HEIGHT):
		for z in range(SIZE):
			for x in range(SIZE):
				var block_id := get_local(x, y, z)
				if block_id == BlockCatalog.AIR:
					continue
				var global_block := Vector3i(chunk_coords.x * SIZE + x, y, chunk_coords.y * SIZE + z)
				var biome := world.biome_at(global_block.x, global_block.z)
				for face in FACE_DEFS:
					var normal: Vector3i = face["normal"]
					if BlockCatalog.is_solid(world.get_block_global(global_block + normal)):
						continue
					var face_color := BlockCatalog.face_color(block_id, normal, biome, global_block)
					var corners: Array = face["corners"]
					for corner in corners:
						vertices.append(Vector3(x, y, z) + corner)
						normals.append(Vector3(normal))
						colors.append(face_color)
					indices.append_array(PackedInt32Array([vertex_index, vertex_index + 1, vertex_index + 2, vertex_index, vertex_index + 2, vertex_index + 3]))
					vertex_index += 4

	if vertices.is_empty():
		return
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(0, _surface_material)

	mesh_instance = MeshInstance3D.new()
	mesh_instance.name = "VoxelMesh"
	mesh_instance.mesh = mesh
	add_child(mesh_instance)

	collision_body = StaticBody3D.new()
	collision_body.name = "VoxelCollision"
	collision_body.collision_layer = 1
	collision_body.collision_mask = 1
	var collision_shape := CollisionShape3D.new()
	collision_shape.shape = mesh.create_trimesh_shape()
	collision_body.add_child(collision_shape)
	add_child(collision_body)
