extends Node3D
class_name VoxelWorld

signal block_changed(position: Vector3i, old_block: int, new_block: int)

const CHUNK_SIZE := VoxelChunk.SIZE
const WORLD_HEIGHT := VoxelChunk.HEIGHT
const CHUNK_SCRIPT := preload("res://scripts/voxel_chunk.gd")

@export_range(1, 4, 1) var render_distance := 2
var seed_value := 0
var chunks: Dictionary = {} # Vector2i -> VoxelChunk
var changes: Dictionary = {} # "x,y,z" -> block id, including AIR edits
var player_reference: Node3D
var current_center := Vector2i(999999, 999999)
var _sync_busy := false
var _stream_clock := 0.0
var _height_noise: FastNoiseLite
var _temperature_noise: FastNoiseLite
var _moisture_noise: FastNoiseLite
var _tree_noise: FastNoiseLite
var _coal_noise: FastNoiseLite
var _iron_noise: FastNoiseLite

func initialize_world(world_seed: int, saved_changes: Dictionary = {}) -> void:
	seed_value = world_seed
	changes = saved_changes.duplicate(true)
	_setup_noise()
	await _sync_chunks(Vector2i.ZERO)
	current_center = Vector2i.ZERO

func _setup_noise() -> void:
	_height_noise = FastNoiseLite.new()
	_height_noise.seed = seed_value
	_height_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
	_height_noise.frequency = 0.022
	_height_noise.fractal_octaves = 4
	_height_noise.fractal_gain = 0.52

	_temperature_noise = FastNoiseLite.new()
	_temperature_noise.seed = seed_value ^ 0x21A7
	_temperature_noise.frequency = 0.006

	_moisture_noise = FastNoiseLite.new()
	_moisture_noise.seed = seed_value ^ 0x5EED
	_moisture_noise.frequency = 0.009

	_tree_noise = FastNoiseLite.new()
	_tree_noise.seed = seed_value ^ 0x7AEE
	_tree_noise.frequency = 0.12

	_coal_noise = FastNoiseLite.new()
	_coal_noise.seed = seed_value ^ 0xC0A1
	_coal_noise.frequency = 0.095

	_iron_noise = FastNoiseLite.new()
	_iron_noise.seed = seed_value ^ 0x1A0F
	_iron_noise.frequency = 0.14

func _process(delta: float) -> void:
	if player_reference == null or not is_instance_valid(player_reference):
		return
	_stream_clock += delta
	if _stream_clock < 0.5 or _sync_busy:
		return
	_stream_clock = 0.0
	var center := chunk_at_world(player_reference.global_position)
	if center != current_center:
		_sync_to_center(center)

func _sync_to_center(center: Vector2i) -> void:
	if _sync_busy:
		return
	_sync_busy = true
	await _sync_chunks(center)
	current_center = center
	_sync_busy = false

func _sync_chunks(center: Vector2i) -> void:
	var desired: Dictionary = {}
	for cz in range(center.y - render_distance, center.y + render_distance + 1):
		for cx in range(center.x - render_distance, center.x + render_distance + 1):
			desired[Vector2i(cx, cz)] = true

	var missing: Array[VoxelChunk] = []
	for key in desired.keys():
		if not chunks.has(key):
			var chunk: VoxelChunk = CHUNK_SCRIPT.new()
			chunk.chunk_coords = key
			chunk.name = "Chunk_%d_%d" % [key.x, key.y]
			chunk.position = Vector3(key.x * CHUNK_SIZE, 0, key.y * CHUNK_SIZE)
			add_child(chunk)
			chunks[key] = chunk
			missing.append(chunk)

	for chunk in missing:
		_generate_base_terrain(chunk)
	for chunk in missing:
		_generate_trees(chunk)
	for chunk in missing:
		_apply_saved_changes_to_chunk(chunk)

	for key in chunks.keys().duplicate():
		if not desired.has(key):
			var old_chunk: VoxelChunk = chunks[key]
			chunks.erase(key)
			old_chunk.queue_free()

	var mesh_count := 0
	for key in desired.keys():
		var chunk: VoxelChunk = chunks.get(key)
		if chunk == null:
			continue
		chunk.rebuild_mesh(self)
		mesh_count += 1
		if mesh_count % 3 == 0:
			await get_tree().process_frame

func _generate_base_terrain(chunk: VoxelChunk) -> void:
	for z in range(CHUNK_SIZE):
		for x in range(CHUNK_SIZE):
			var wx := chunk.chunk_coords.x * CHUNK_SIZE + x
			var wz := chunk.chunk_coords.y * CHUNK_SIZE + z
			var height := surface_height(wx, wz)
			var biome := biome_at(wx, wz)
			for y in range(height + 1):
				var block_id := BlockCatalog.STONE
				if y == 0:
					block_id = BlockCatalog.STONE
				elif y == height:
					match biome:
						"desert": block_id = BlockCatalog.SAND
						"snow": block_id = BlockCatalog.SNOW
						"swamp": block_id = BlockCatalog.MOSS
						_: block_id = BlockCatalog.GRASS
				elif y >= height - 3:
					if biome == "desert":
						block_id = BlockCatalog.SAND
					elif biome == "swamp" and y >= height - 1:
						block_id = BlockCatalog.CLAY
					else:
						block_id = BlockCatalog.DIRT
				else:
					var depth := height - y
					if depth > 3 and _coal_noise.get_noise_3d(float(wx), float(y), float(wz)) > 0.58:
						block_id = BlockCatalog.COAL_ORE
					elif depth > 7 and _iron_noise.get_noise_3d(float(wx), float(y), float(wz)) > 0.62:
						block_id = BlockCatalog.IRON_ORE
			chunk.set_local(x, y, z, block_id)

func _generate_trees(chunk: VoxelChunk) -> void:
	for z in range(3, CHUNK_SIZE - 3):
		for x in range(3, CHUNK_SIZE - 3):
			var wx := chunk.chunk_coords.x * CHUNK_SIZE + x
			var wz := chunk.chunk_coords.y * CHUNK_SIZE + z
			var biome := biome_at(wx, wz)
			if biome not in ["forest", "plains", "swamp", "snow"]:
				continue
			var threshold := 0.43 if biome in ["forest", "snow"] else 0.70
			if _tree_noise.get_noise_2d(wx, wz) < threshold:
				continue
			var top := surface_height(wx, wz)
			if top < 3 or top > WORLD_HEIGHT - 9:
				continue
			var local_top := top
			if chunk.get_local(x, local_top, z) not in [BlockCatalog.GRASS, BlockCatalog.MOSS, BlockCatalog.SNOW]:
				continue
			var trunk_height := 4 + int(abs(_tree_noise.get_noise_2d(wx + 317, wz - 129)) * 3.0)
			for dy in range(1, trunk_height + 1):
				chunk.set_local(x, local_top + dy, z, BlockCatalog.LOG)
			var crown_y := local_top + trunk_height
			for dy in range(-2, 3):
				for dz in range(-2, 3):
					for dx in range(-2, 3):
						if abs(dx) + abs(dz) + abs(dy) > 5:
							continue
						var lx := x + dx
						var ly := crown_y + dy
						var lz := z + dz
						if chunk.get_local(lx, ly, lz) == BlockCatalog.AIR:
							chunk.set_local(lx, ly, lz, BlockCatalog.LEAVES)

func _apply_saved_changes_to_chunk(chunk: VoxelChunk) -> void:
	for key in changes.keys():
		var parts := String(key).split(",")
		if parts.size() != 3:
			continue
		var pos := Vector3i(int(parts[0]), int(parts[1]), int(parts[2]))
		if chunk_at_world(pos) != chunk.chunk_coords:
			continue
		if pos.y < 0 or pos.y >= WORLD_HEIGHT:
			continue
		chunk.set_local(pos.x - chunk.chunk_coords.x * CHUNK_SIZE, pos.y, pos.z - chunk.chunk_coords.y * CHUNK_SIZE, int(changes[key]))

func get_block_global(pos: Vector3i) -> int:
	if pos.y < 0 or pos.y >= WORLD_HEIGHT:
		return BlockCatalog.STONE if pos.y < 0 else BlockCatalog.AIR
	var key := chunk_at_world(pos)
	var chunk: VoxelChunk = chunks.get(key)
	if chunk == null:
		return BlockCatalog.AIR
	return chunk.get_local(pos.x - key.x * CHUNK_SIZE, pos.y, pos.z - key.y * CHUNK_SIZE)

func set_block_global(pos: Vector3i, block_id: int, persist: bool = true) -> bool:
	if pos.y <= 0 or pos.y >= WORLD_HEIGHT:
		return false
	var key := chunk_at_world(pos)
	var chunk: VoxelChunk = chunks.get(key)
	if chunk == null:
		return false
	var lx := pos.x - key.x * CHUNK_SIZE
	var lz := pos.z - key.y * CHUNK_SIZE
	var old_id := chunk.get_local(lx, pos.y, lz)
	if old_id == block_id:
		return false
	chunk.set_local(lx, pos.y, lz, block_id)
	if persist:
		changes[_position_key(pos)] = block_id
	chunk.rebuild_mesh(self)
	if lx == 0:
		_rebuild_chunk_key(key + Vector2i(-1, 0))
	elif lx == CHUNK_SIZE - 1:
		_rebuild_chunk_key(key + Vector2i(1, 0))
	if lz == 0:
		_rebuild_chunk_key(key + Vector2i(0, -1))
	elif lz == CHUNK_SIZE - 1:
		_rebuild_chunk_key(key + Vector2i(0, 1))
	block_changed.emit(pos, old_id, block_id)
	return true

func _rebuild_chunk_key(key: Vector2i) -> void:
	var chunk: VoxelChunk = chunks.get(key)
	if chunk != null:
		chunk.rebuild_mesh(self)

func break_block(pos: Vector3i) -> String:
	var block_id := get_block_global(pos)
	if block_id == BlockCatalog.AIR:
		return ""
	if not set_block_global(pos, BlockCatalog.AIR, true):
		return ""
	return BlockCatalog.drop_for(block_id)

func place_block(pos: Vector3i, block_id: int) -> bool:
	if block_id == BlockCatalog.AIR or not chunks.has(chunk_at_world(pos)):
		return false
	if get_block_global(pos) != BlockCatalog.AIR:
		return false
	return set_block_global(pos, block_id, true)

func surface_height(x: int, z: int) -> int:
	var broad := _height_noise.get_noise_2d(float(x), float(z))
	var detail := _height_noise.get_noise_2d(float(x) * 2.6 + 77.0, float(z) * 2.6 - 131.0)
	var ridge := 1.0 - abs(_height_noise.get_noise_2d(float(x) * 0.65, float(z) * 0.65))
	return clampi(int(17.0 + broad * 9.0 + detail * 3.0 + ridge * 5.0), 5, WORLD_HEIGHT - 10)

func biome_at(x: int, z: int) -> String:
	var temp := _temperature_noise.get_noise_2d(float(x), float(z))
	var wet := _moisture_noise.get_noise_2d(float(x), float(z))
	var altitude := surface_height(x, z)
	if altitude >= 29:
		return "mountain"
	if temp < -0.42:
		return "snow"
	if temp > 0.34 and wet < -0.22:
		return "desert"
	if wet > 0.56 and altitude < 19:
		return "swamp"
	if wet > 0.18:
		return "forest"
	return "plains"

func chunk_at_world(pos: Vector3i) -> Vector2i:
	return Vector2i(floori(float(pos.x) / CHUNK_SIZE), floori(float(pos.z) / CHUNK_SIZE))

func chunk_at_world_position(pos: Vector3) -> Vector2i:
	return Vector2i(floori(pos.x / float(CHUNK_SIZE)), floori(pos.z / float(CHUNK_SIZE)))

func _position_key(pos: Vector3i) -> String:
	return "%d,%d,%d" % [pos.x, pos.y, pos.z]

func export_changes() -> Dictionary:
	return changes.duplicate(true)

func visible_chunk_count() -> int:
	return chunks.size()
