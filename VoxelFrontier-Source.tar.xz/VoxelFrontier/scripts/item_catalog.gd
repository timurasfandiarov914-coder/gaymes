extends RefCounted
class_name ItemCatalog

const ITEMS: Dictionary = {
	"grass_block": {"name": "Grass block", "short": "GRS", "max_stack": 64, "block": BlockCatalog.GRASS},
	"dirt": {"name": "Dirt", "short": "DIR", "max_stack": 64, "block": BlockCatalog.DIRT},
	"stone": {"name": "Stone", "short": "STN", "max_stack": 64, "block": BlockCatalog.STONE},
	"sand": {"name": "Sand", "short": "SND", "max_stack": 64, "block": BlockCatalog.SAND},
	"log": {"name": "Log", "short": "LOG", "max_stack": 64, "block": BlockCatalog.LOG},
	"leaves": {"name": "Leaves", "short": "LEF", "max_stack": 64, "block": BlockCatalog.LEAVES},
	"coal": {"name": "Coal", "short": "COL", "max_stack": 64},
	"iron_ore": {"name": "Iron ore", "short": "IRN", "max_stack": 64, "block": BlockCatalog.IRON_ORE},
	"snow_block": {"name": "Snow block", "short": "SNW", "max_stack": 64, "block": BlockCatalog.SNOW},
	"clay": {"name": "Clay", "short": "CLY", "max_stack": 64, "block": BlockCatalog.CLAY},
	"moss": {"name": "Moss block", "short": "MOS", "max_stack": 64, "block": BlockCatalog.MOSS},
	"planks": {"name": "Wood planks", "short": "PLK", "max_stack": 64, "block": BlockCatalog.PLANKS},
	"bricks": {"name": "Stone bricks", "short": "BRK", "max_stack": 64, "block": BlockCatalog.BRICKS},
	"torch": {"name": "Torch", "short": "TOR", "max_stack": 64, "block": BlockCatalog.TORCH},
	"stick": {"name": "Stick", "short": "STK", "max_stack": 64},
	"berry": {"name": "Wild berries", "short": "BER", "max_stack": 32, "food": 18},
	"bread": {"name": "Bread", "short": "BRD", "max_stack": 16, "food": 35},
	"wooden_pickaxe": {"name": "Wooden pickaxe", "short": "PCK", "max_stack": 1, "tool": "pickaxe", "tier": 1, "durability": 80},
	"wooden_axe": {"name": "Wooden axe", "short": "AXE", "max_stack": 1, "tool": "axe", "tier": 1, "durability": 80},
	"stone_pickaxe": {"name": "Stone pickaxe", "short": "SPK", "max_stack": 1, "tool": "pickaxe", "tier": 2, "durability": 160}
}

const RECIPES: Array[Dictionary] = [
	{"name": "Planks", "inputs": {"log": 1}, "output": "planks", "count": 4},
	{"name": "Sticks", "inputs": {"planks": 2}, "output": "stick", "count": 4},
	{"name": "Torch", "inputs": {"stick": 1, "coal": 1}, "output": "torch", "count": 4},
	{"name": "Wooden pickaxe", "inputs": {"planks": 3, "stick": 2}, "output": "wooden_pickaxe", "count": 1},
	{"name": "Wooden axe", "inputs": {"planks": 3, "stick": 2}, "output": "wooden_axe", "count": 1},
	{"name": "Stone bricks", "inputs": {"stone": 4}, "output": "bricks", "count": 4},
	{"name": "Stone pickaxe", "inputs": {"stone": 3, "stick": 2}, "output": "stone_pickaxe", "count": 1},
	{"name": "Bread", "inputs": {"berry": 4}, "output": "bread", "count": 1}
]

static func get_item(item_id: String) -> Dictionary:
	return ITEMS.get(item_id, {})

static func item_name(item_id: String) -> String:
	return String(ITEMS.get(item_id, {}).get("name", item_id))

static func short_name(item_id: String) -> String:
	return String(ITEMS.get(item_id, {}).get("short", "???"))

static func block_for_item(item_id: String) -> int:
	return int(ITEMS.get(item_id, {}).get("block", BlockCatalog.AIR))
