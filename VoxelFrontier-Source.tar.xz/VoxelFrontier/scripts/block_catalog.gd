extends RefCounted
class_name BlockCatalog

const AIR := 0
const GRASS := 1
const DIRT := 2
const STONE := 3
const SAND := 4
const LOG := 5
const LEAVES := 6
const COAL_ORE := 7
const IRON_ORE := 8
const SNOW := 9
const CLAY := 10
const MOSS := 11
const PLANKS := 12
const BRICKS := 13
const TORCH := 14

const DATA: Dictionary = {
	AIR: {"name": "Air", "solid": false},
	GRASS: {"name": "Grass block", "solid": true},
	DIRT: {"name": "Dirt", "solid": true},
	STONE: {"name": "Stone", "solid": true},
	SAND: {"name": "Sand", "solid": true},
	LOG: {"name": "Wood log", "solid": true},
	LEAVES: {"name": "Leaves", "solid": true},
	COAL_ORE: {"name": "Coal ore", "solid": true},
	IRON_ORE: {"name": "Iron ore", "solid": true},
	SNOW: {"name": "Snow", "solid": true},
	CLAY: {"name": "Clay", "solid": true},
	MOSS: {"name": "Moss", "solid": true},
	PLANKS: {"name": "Planks", "solid": true},
	BRICKS: {"name": "Stone bricks", "solid": true},
	TORCH: {"name": "Torch", "solid": false}
}

const DROPS: Dictionary = {
	GRASS: "grass_block", DIRT: "dirt", STONE: "stone", SAND: "sand",
	LOG: "log", LEAVES: "leaves", COAL_ORE: "coal", IRON_ORE: "iron_ore",
	SNOW: "snow_block", CLAY: "clay", MOSS: "moss", PLANKS: "planks",
	BRICKS: "bricks", TORCH: "torch"
}

const PLACEABLE: Dictionary = {
	"grass_block": GRASS, "dirt": DIRT, "stone": STONE, "sand": SAND,
	"log": LOG, "leaves": LEAVES, "coal_ore": COAL_ORE, "iron_ore": IRON_ORE,
	"snow_block": SNOW, "clay": CLAY, "moss": MOSS, "planks": PLANKS,
	"bricks": BRICKS, "torch": TORCH
}

static func is_solid(block_id: int) -> bool:
	return bool(DATA.get(block_id, DATA[AIR]).get("solid", false))

static func drop_for(block_id: int) -> String:
	return String(DROPS.get(block_id, ""))

static func label(block_id: int) -> String:
	return String(DATA.get(block_id, DATA[AIR]).get("name", "Unknown"))

static func face_color(block_id: int, normal: Vector3i, biome: String, position: Vector3i) -> Color:
	var base := Color(0.5, 0.5, 0.5)
	match block_id:
		GRASS:
			if normal.y > 0:
				match biome:
					"forest": base = Color(0.20, 0.43, 0.19)
					"swamp": base = Color(0.25, 0.39, 0.20)
					"mountain": base = Color(0.36, 0.46, 0.31)
					_: base = Color(0.32, 0.59, 0.25)
			else:
				base = Color(0.39, 0.34, 0.24)
		DIRT: base = Color(0.43, 0.31, 0.20)
		STONE: base = Color(0.48, 0.51, 0.54)
		SAND: base = Color(0.78, 0.69, 0.45)
		LOG: base = Color(0.39, 0.25, 0.13) if normal.y == 0 else Color(0.62, 0.45, 0.27)
		LEAVES: base = Color(0.19, 0.42, 0.20)
		COAL_ORE: base = Color(0.28, 0.30, 0.32)
		IRON_ORE: base = Color(0.58, 0.42, 0.34)
		SNOW: base = Color(0.82, 0.88, 0.92)
		CLAY: base = Color(0.56, 0.57, 0.53)
		MOSS: base = Color(0.28, 0.40, 0.25)
		PLANKS: base = Color(0.61, 0.42, 0.24)
		BRICKS: base = Color(0.43, 0.45, 0.47)
		TORCH: base = Color(1.0, 0.69, 0.20)
	var hash_value := abs(position.x * 73856093 + position.y * 19349663 + position.z * 83492791) % 13
	var variation := 0.94 + float(hash_value) * 0.01
	var shade := 1.0
	if normal.y < 0:
		shade = 0.68
	elif normal.x != 0:
		shade = 0.82
	elif normal.z != 0:
		shade = 0.90
	return Color(base.r * variation * shade, base.g * variation * shade, base.b * variation * shade, base.a)
