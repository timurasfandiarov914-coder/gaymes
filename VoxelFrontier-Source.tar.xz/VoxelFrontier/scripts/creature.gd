extends CharacterBody3D
class_name FrontierCreature

signal removed(creature: FrontierCreature)

const WALK_SPEED := 1.5
var species_id := "field_hare"
var world: VoxelWorld
var target_player: FrontierPlayer
var health := 20.0
var hostile := false
var drop_item := "berry"
var drop_count := 1
var _wander_direction := Vector3.ZERO
var _decision_timer := 0.0
var _attack_timer := 0.0
var _dead := false

func configure(species: String, world_ref: VoxelWorld, player_ref: FrontierPlayer) -> void:
	species_id = species
	world = world_ref
	target_player = player_ref
	match species_id:
		"trail_fox":
			hostile = false
			health = 28.0
			drop_item = "berry"
			drop_count = 2
		"moss_golem":
			hostile = true
			health = 65.0
			drop_item = "stone"
			drop_count = 4
		"night_stalker":
			hostile = true
			health = 42.0
			drop_item = "coal"
			drop_count = 2
		_:
			hostile = false
			health = 16.0
			drop_item = "berry"
			drop_count = 1

func _ready() -> void:
	collision_layer = 4
	collision_mask = 1
	_build_visual()
	_decision_timer = 1.0

func _build_visual() -> void:
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.30 if species_id != "moss_golem" else 0.48
	capsule.height = 0.95 if species_id != "moss_golem" else 1.65
	var shape := CollisionShape3D.new()
	shape.shape = capsule
	shape.position.y = capsule.height * 0.5
	add_child(shape)
	var main_color := Color(0.63, 0.49, 0.35)
	var head_color := Color(0.77, 0.66, 0.48)
	var body_size := Vector3(0.52, 0.42, 0.72)
	var head_size := Vector3(0.34, 0.32, 0.34)
	var body_y := 0.46
	match species_id:
		"trail_fox":
			main_color = Color(0.73, 0.33, 0.19)
			head_color = Color(0.84, 0.55, 0.33)
		"moss_golem":
			main_color = Color(0.31, 0.41, 0.35)
			head_color = Color(0.43, 0.52, 0.42)
			body_size = Vector3(0.86, 0.94, 0.72)
			head_size = Vector3(0.55, 0.48, 0.52)
			body_y = 0.78
		"night_stalker":
			main_color = Color(0.16, 0.19, 0.24)
			head_color = Color(0.31, 0.36, 0.41)
			body_size = Vector3(0.60, 0.82, 0.46)
			body_y = 0.65
	var body_mesh := BoxMesh.new()
	body_mesh.size = body_size
	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = main_color
	body_mat.roughness = 0.95
	var body_instance := MeshInstance3D.new()
	body_instance.mesh = body_mesh
	body_instance.material_override = body_mat
	body_instance.position.y = body_y
	add_child(body_instance)
	var head_mesh := BoxMesh.new()
	head_mesh.size = head_size
	var head_mat := StandardMaterial3D.new()
	head_mat.albedo_color = head_color
	var head_instance := MeshInstance3D.new()
	head_instance.mesh = head_mesh
	head_instance.material_override = head_mat
	head_instance.position = Vector3(0, body_y + body_size.y * 0.42, -body_size.z * 0.43)
	add_child(head_instance)
	if species_id == "field_hare":
		for i in range(2):
			var ear := BoxMesh.new()
			ear.size = Vector3(0.09, 0.34, 0.10)
			var ear_instance := MeshInstance3D.new()
			ear_instance.mesh = ear
			ear_instance.material_override = head_mat
			ear_instance.position = Vector3(-0.10 + i * 0.20, body_y + 0.65, -body_size.z * 0.45)
			add_child(ear_instance)
	if species_id == "night_stalker" or species_id == "moss_golem":
		var eye_mesh := BoxMesh.new()
		eye_mesh.size = Vector3(0.07, 0.07, 0.035)
		var eye_mat := StandardMaterial3D.new()
		eye_mat.albedo_color = Color(0.94, 0.61, 0.29) if species_id == "night_stalker" else Color(0.73, 0.82, 0.55)
		eye_mat.emission_enabled = true
		eye_mat.emission = eye_mat.albedo_color * 0.25
		for i in range(2):
			var eye := MeshInstance3D.new()
			eye.mesh = eye_mesh
			eye.material_override = eye_mat
			eye.position = Vector3(-0.13 + i * 0.26, body_y + body_size.y * 0.48, -body_size.z * 0.52 - 0.025)
			add_child(eye)

func _physics_process(delta: float) -> void:
	if _dead or world == null or target_player == null or not is_instance_valid(target_player):
		return
	_decision_timer -= delta
	_attack_timer = maxf(0.0, _attack_timer - delta)
	var to_player := target_player.global_position - global_position
	to_player.y = 0.0
	var distance := to_player.length()
	var desired := Vector3.ZERO
	if hostile and distance < (13.0 if species_id == "night_stalker" else 9.0):
		desired = to_player.normalized()
		if distance < 1.65 and _attack_timer <= 0.0:
			target_player.take_damage(7.0 if species_id == "night_stalker" else 5.0)
			_attack_timer = 1.2
	elif not hostile and distance < 4.5:
		desired = -to_player.normalized()
	elif _decision_timer <= 0.0:
		var angle := randf_range(-PI, PI)
		_wander_direction = Vector3(cos(angle), 0, sin(angle))
		_decision_timer = randf_range(1.5, 4.5)
		desired = _wander_direction
	else:
		desired = _wander_direction

	if desired.length_squared() > 0.01:
		desired = desired.normalized()
		rotation.y = lerp_angle(rotation.y, atan2(-desired.x, -desired.z), delta * 5.0)
		var speed := 2.6 if hostile else WALK_SPEED
		velocity.x = move_toward(velocity.x, desired.x * speed, delta * 7.0)
		velocity.z = move_toward(velocity.z, desired.z * speed, delta * 7.0)
	else:
		velocity.x = move_toward(velocity.x, 0.0, delta * 7.0)
		velocity.z = move_toward(velocity.z, 0.0, delta * 7.0)
	if not is_on_floor():
		velocity.y -= float(ProjectSettings.get_setting("physics/3d/default_gravity")) * delta
	elif velocity.y < 0.0:
		velocity.y = 0.0
	move_and_slide()

func receive_hit(attacker: FrontierPlayer) -> void:
	if _dead:
		return
	health -= 10.0
	if health > 0.0:
		return
	_dead = true
	if attacker != null and attacker.inventory != null:
		if attacker.inventory.can_add_item(drop_item, drop_count):
			attacker.inventory.add_item(drop_item, drop_count)
		else:
			attacker.action_failed.emit("Инвентарь заполнен: %s не получен" % ItemCatalog.item_name(drop_item))
		removed.emit(self)
		queue_free()
