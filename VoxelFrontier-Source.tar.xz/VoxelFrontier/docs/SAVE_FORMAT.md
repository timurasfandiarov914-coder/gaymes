# Save format

Current path: `user://worlds/main_world.json`. The implementation is single-slot, not a multi-world save browser.

The JSON payload includes:

- `save_version`: currently `1`.
- `seed`: integer used for deterministic baseline terrain.
- `creative`: current gameplay mode.
- `changes`: string coordinate keys (`x,y,z`) mapped to block IDs. AIR edits are meaningful and must be retained.
- `player_position`: three numeric coordinates.
- `health`, `hunger`: player status values.
- `view`: yaw and pitch.
- `inventory`: serialized slot dictionaries with item IDs/counts and optional durability.
- `time_of_day`: normalized day-cycle progress.
- `saved_at_unix`: timestamp assigned by the save manager.

Writing goes to a `.tmp` file and flushes it before renaming the previous save to `.bak`, then replacing the main path. If replacement fails, the previous path is restored when possible. The current loader validates JSON shape, version ceiling, and required seed/change fields. It does **not** yet automatically recover from `.bak`, verify a checksum, preserve creature/container states, or migrate multiple historical schema versions. Inventory restoration discards unknown item IDs and clamps quantities to catalog stack limits.

Any incompatible schema change must bump `SAVE_VERSION` and provide an explicit migration or clear rejection behavior. Do not overwrite user data merely to accommodate a failed parse.
