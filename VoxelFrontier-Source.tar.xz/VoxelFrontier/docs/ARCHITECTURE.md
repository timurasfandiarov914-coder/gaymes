# Architecture

## Runtime ownership

`scenes/main.tscn` owns the `Main` (`scripts/main.gd`) root. The root creates the environment, touch HUD, world, inventory and player when a world is started. The current design deliberately keeps world generation and item definitions data-driven enough to expand, while avoiding a separate scene node for every voxel.

- `VoxelWorld` owns seed-derived noise, loaded chunks, changed-block deltas, and chunk streaming around the player.
- `VoxelChunk` stores a dense `PackedByteArray` in a `16 × 16 × 48` grid, creates a mesh from exposed voxel faces, and derives a trimesh collision shape from that mesh.
- `BlockCatalog` is the canonical mapping from block IDs to solidity, drops, and face color.
- `ItemCatalog` contains item definitions and crafting recipes.
- `FrontierInventory` owns 24 item slots, eight quickbar slots, item stacking, ingredient removal, crafting rollback, food consumption, and durability.
- `FrontierPlayer` handles first-person camera/movement, block raycasts, placing/mining, health, hunger, and player state.
- `FrontierCreature` implements four distinct parameter sets and lightweight local steering.
- `FrontierHUD` owns touch/mouse UI presentation and turns interaction into signals; `Main` routes those signals into systems.
- `SaveManager` serializes the current single world to the app's user-data directory using a temporary write and backup rename.

## Dependency direction

The HUD emits semantic actions rather than editing the world. The player asks `VoxelWorld` to mutate blocks and `FrontierInventory` to consume/gain items. The world references the catalogs only for terrain and block behavior. `Main` is the composition root: it wires signals and lifecycle, but is not intended to become a container for all voxel algorithms.

## Rendering and collision

Chunk voxel data is authoritative. Meshes and trimesh collision are generated views of that data and are rebuilt after mutations. Adjacent chunks are queried for neighbor block data so the shared boundary does not intentionally generate a visible internal face when the neighboring chunk is loaded. The current mesh builder removes hidden faces but does **not** yet implement greedy meshing, threaded meshing, ambient occlusion, a dedicated transparent-material pass, or a light-propagation field.

## Extension rules

When adding a block or item, add a stable ID and its catalog metadata first, then write tests for its drop/place/craft behavior. When changing stored fields, bump `SaveManager.SAVE_VERSION` and write a migration or explicit rejection behavior. Avoid renaming `com.voxelfrontier.game` or changing the persistent release signing key after first distributing a signed release.

## Known architecture limits

This is a playable-core foundation, not the full master specification. It has one saved world slot, a simple survival loop, a small recipe list, basic creatures without full pathfinding, and no completed audio/weather/liquid/multiplayer stack. Runtime profiling and a Godot import/test pass are still required before a release claim.
