# World generation

## Coordinates and chunks

The current chunk dimensions are `16 × 16 × 48` blocks. Chunk coordinates are horizontal `(chunk_x, chunk_z)` pairs. The global-to-chunk conversion uses floor semantics, so `x=-1` maps to chunk `-1` rather than chunk `0`. The baseline render radius is two chunks in each horizontal direction, with chunk creation and mesh builds yielding periodically to the main loop.

Each block is stored as one byte. Unchanged blocks are derived from the seed; player edits are stored as sparse coordinate keys of the form `x,y,z` and applied after deterministic terrain and tree generation. AIR-valued edits are retained so a mined voxel does not reappear after reload.

## Seed-derived terrain

The current implementation uses independently seeded `FastNoiseLite` fields for height, temperature, moisture, tree density, coal, and iron. Terrain height is clamped into the chunk's vertical range. The biome classifier currently returns plains, forest, desert, snow, swamp, or mountain based on climate noise and altitude. Surface and near-surface blocks are chosen by biome; deeper blocks may contain coal or iron.

The algorithm is deterministic for a fixed seed, engine/noise implementation, and generator version. Determinism should not be assumed across a future change to the algorithm: save data is versioned and a future generator migration may need to preserve old worlds' baseline interpretation.

## Current limitations

This generation step does not yet create caves, rivers, lakes, oceans, simulated fluids, underwater content, settlement structures, loot dungeons, biome-specific custom assets, or all requested biome types. Trees are generated only at interior positions of each chunk to avoid cross-chunk canopy writes; this leaves a sparse margin near chunk edges. Meshing removes hidden solid faces, but currently uses per-face quads rather than greedy meshing. All of these are explicit scope gaps, not hidden claims of completion.
