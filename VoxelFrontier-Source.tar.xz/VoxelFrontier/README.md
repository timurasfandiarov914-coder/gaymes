# Voxel Frontier

**Voxel Frontier** is an original, offline-first 3D voxel survival sandbox for Android, built with **Godot 4.7.2-stable** and GDScript. It takes genre-level inspiration from procedural block-building games while using project-authored code, generated materials, and an independent identity.

> **Development status: playable-core foundation, not a completed commercial-quality game.** The project currently focuses on the world/chunk pipeline, first-person controls, block interaction, a starter inventory/crafting loop, survival statistics, and local saves. It does not yet meet every feature in the full master specification; the known gaps are documented below.

## Current implementation

- Procedural 3D terrain with a stable seed, height and climate noise, surface materials, ore pockets, and biome classification.
- Chunk-based block storage, visible-face mesh generation, trimesh collision, player-centered chunk streaming, and persistent block-change deltas.
- First-person movement, gravity, jump, sprint on keyboard, raycast mining/placement, and camera look.
- Mobile touch HUD with movement joystick, swipe look, quickbar, jump, mine, place, inventory, eat, pause, and menu controls.
- Item stacks, stack limits, hotbar selection, a starter recipe list, craft validation, and food.
- Survival health and hunger, death/respawn flow, a day/night lighting cycle, and a small initial set of simple creature behaviors.
- Single-world local save file with seed, changed blocks, player position/status, view rotation, inventory, mode, and time-of-day. Writes use a temporary file and backup before replacement.
- Godot project import, automated core tests, smoke test, and a GitHub Actions Android export workflow.

## Controls

### Touch

Left joystick moves; push it fully to the edge to sprint. Swipe in open screen space looks around. The right side contains jump, mine, place, inventory, and eat controls. Tap quickbar slots to select a stack. Tap a crafting recipe to craft it.

### Keyboard and mouse

- `W A S D` / arrow keys: move
- Mouse: look
- `Space`: jump
- `Shift`: run
- Left mouse: mine / hit creature
- Right mouse: place block
- `E`: inventory/crafting
- `F`: eat selected food
- `Esc`: pause / close inventory
- `1`–`8`: quickbar slots

## Building Android APK with GitHub Actions

The project includes `.github/workflows/android.yml`. On a push to `main`, it imports the project, runs the core tests and a headless smoke test, exports `build/VoxelFrontier.apk`, checks the APK archive, and uploads it as a workflow artifact.

For **repeatable install-over-update release signing**, configure these repository Actions secrets before creating a version tag such as `v0.1.0`:

- `ANDROID_KEYSTORE_BASE64`: base64-encoded, persistent Android release keystore.
- `ANDROID_KEYSTORE_PASSWORD`: keystore password.
- `ANDROID_KEY_ALIAS`: key alias.
- `ANDROID_KEY_PASSWORD`: key password. Godot's current Android exporter requires the key password and keystore password to match; the workflow checks this explicitly.

The release keystore must be created once, stored safely outside the repository, and backed up. Do not use a temporary debug keystore for a public release: Android will reject future in-place updates signed with a different key.

Tags matching `v*.*.*` request a signed release build and publish a GitHub Release with the asset named exactly `VoxelFrontier.apk`. The workflow intentionally fails a tagged release if the persistent signing key is missing, rather than silently producing an APK that may not update an existing installation.

Do not commit the keystore or its password to the repository. The key must be backed up securely; losing it can prevent future in-place updates.

## Local development

Install the matching stable Godot 4.7.2 release and Android export templates from the [official Godot archive](https://godotengine.org/download/archive/4.7.2-stable/). Open this directory as a Godot project. To validate and export from a configured command-line environment:

```bash
python3 tools/validate_project.py
godot --headless --editor --path . --quit
godot --headless --path . --script res://tests/core_tests.gd
godot --headless --path . --quit-after 5
godot --headless --path . --export-debug "Android" build/VoxelFrontier.apk
```

## Save data

The current single save lives at `user://worlds/main_world.json`. The save format has a version field and stores only block edits over the deterministic generated baseline rather than serializing every unchanged voxel. Older or malformed saves are not overwritten silently.

## Known gaps against the full specification

This repository is **not yet a finished release**. The current foundation does not yet include a full creative catalogue browser, several fully distinct biomes with custom assets, rivers/oceans and simulated fluids, caves and multi-room dungeons, structures/settlements, a broad validated recipe economy, tool-tier mining rules, armor, full enemy pathfinding, persistent creature/container states, weather simulation, original audio/music, rebinding and layout customization, cloud backups, or multiplayer. Current creature navigation is lightweight steering, not robust pathfinding. The single-save UI is intentionally simple. These systems need implementation and real runtime profiling before the game can be described as complete.

## License and content provenance

Project-authored code and documentation are MIT-licensed. The first version includes no third-party textures, models, or audio and no extracted Minecraft content. See [`THIRD_PARTY_LICENSES.md`](THIRD_PARTY_LICENSES.md) for tooling and provenance notes.
