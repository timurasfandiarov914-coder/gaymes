#!/usr/bin/env python3
"""Fast structural checks for Voxel Frontier; this is not a Godot parser."""
from __future__ import annotations

import configparser
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
checks = 0


def check(condition: bool, message: str) -> None:
    global checks
    checks += 1
    if not condition:
        errors.append(message)


def read(path: str) -> str:
    file = ROOT / path
    check(file.is_file(), f"Required file missing: {path}")
    if not file.is_file():
        return ""
    return file.read_text(encoding="utf-8")


project_text = read("project.godot")
read("scenes/main.tscn")
read("icon.svg")
item_text = read("scripts/item_catalog.gd")
block_text = read("scripts/block_catalog.gd")
workflow_text = read(".github/workflows/android.yml")
read("tests/core_tests.gd")
read("README.md")
read("docs/ARCHITECTURE.md")
read("docs/WORLD_GENERATION.md")
read("docs/CONTENT.md")
read("docs/SAVE_FORMAT.md")

# Project settings parsing. Godot's config is INI-like, so disable interpolation.
parser = configparser.ConfigParser(interpolation=None, strict=True)
try:
    parser.read_string("\n".join(line for line in project_text.splitlines() if not line.startswith("config_version=")))
except configparser.Error as exc:
    errors.append(f"project.godot is not valid INI-style configuration: {exc}")
else:
    application_name = parser.get("application", "config/name", fallback="").strip('"')
    main_scene = parser.get("application", "run/main_scene", fallback="").strip('"')
    version = parser.get("application", "config/version", fallback="").strip('"')
    icon_path = parser.get("application", "config/icon", fallback="").strip('"')
    check(application_name == "Voxel Frontier", "Application name must be Voxel Frontier")
    check(icon_path == "res://icon.svg" and (ROOT / "icon.svg").is_file(), "Original application icon is missing")
    check(main_scene == "res://scenes/main.tscn", "Main scene must point to res://scenes/main.tscn")
    check(version == "0.1.0", "Project baseline version should be 0.1.0")

preset_text = read("export_presets.cfg")
check('name="Android"' in preset_text, "Android export preset is missing")
check('package/unique_name="com.voxelfrontier.game"' in preset_text,
      "Android package ID changed from the baseline")
check('export_path="build/VoxelFrontier.apk"' in preset_text,
      "APK output filename must remain VoxelFrontier.apk")
check('architectures/arm64-v8a=true' in preset_text,
      "Android arm64-v8a export must be enabled")

# Ensure every static preload refers to a file in this project.
for source in sorted((ROOT / "scripts").glob("*.gd")) + [ROOT / "tests/core_tests.gd"]:
    content = source.read_text(encoding="utf-8")
    for match in re.finditer(r'preload\("res://([^"]+)"\)', content):
        relative = match.group(1)
        check((ROOT / relative).is_file(), f"{source.relative_to(ROOT)} preloads missing resource: {relative}")

# Content catalog sanity checks (outer dictionary keys only).
item_section = item_text.split("const RECIPES", 1)[0]
item_ids = set(re.findall(r'^\t"([a-z0-9_]+)"\s*:\s*\{', item_section, flags=re.MULTILINE))
check(len(item_ids) >= 18, f"Expected at least 18 item definitions, found {len(item_ids)}")
recipe_section = item_text.split("const RECIPES", 1)[1] if "const RECIPES" in item_text else ""
outputs = re.findall(r'"output"\s*:\s*"([a-z0-9_]+)"', recipe_section)
inputs_blocks = re.findall(r'"inputs"\s*:\s*\{([^}]*)\}', recipe_section)
check(len(outputs) >= 8, f"Expected at least 8 recipes, found {len(outputs)}")
for output in outputs:
    check(output in item_ids, f"Recipe output has no item definition: {output}")
for block in inputs_blocks:
    for item_id in re.findall(r'"([a-z0-9_]+)"\s*:', block):
        check(item_id in item_ids, f"Recipe input has no item definition: {item_id}")

# Ensure item-to-block references and block drops are resolvable.
block_ids = set(re.findall(r'^\s*const\s+([A-Z_]+)\s*:=\s*(\d+)', block_text, flags=re.MULTILINE))
valid_block_numbers = {int(number) for _, number in block_ids}
check(0 in valid_block_numbers and 14 in valid_block_numbers,
      "Block catalog should define AIR=0 through TORCH=14")
for match in re.finditer(r'"block"\s*:\s*BlockCatalog\.([A-Z_]+)', item_section):
    name = match.group(1)
    check(any(block_name == name for block_name, _ in block_ids), f"Item references unknown block: {name}")

# Keep this validator dependency-free: YAML is separately checked during development and
# GitHub Actions itself validates the workflow when it starts.
check("jobs:" in workflow_text and "validate-and-build:" in workflow_text,
      "Android workflow job is missing")
check("actions/checkout@v4" in workflow_text and "actions/upload-artifact@v4" in workflow_text,
      "Android workflow must checkout source and upload build output")

# Lightweight indentation checks catch missing block bodies before Godot parses GDScript.
# This is deliberately not described as a full GDScript parser; runtime CI remains authoritative.
for source in sorted((ROOT / "scripts").glob("*.gd")) + [ROOT / "tests/core_tests.gd"]:
    lines = source.read_text(encoding="utf-8").splitlines()
    for index, line in enumerate(lines):
        stripped = line.lstrip("\t ")
        if not stripped or stripped.startswith("#"):
            continue
        # A line ending in ':' with no inline statement opens a block. Its next
        # meaningful line must be indented further. This catches subtle errors
        # such as an emit() accidentally aligned with the preceding if statement.
        if not stripped.endswith(":"):
            continue
        current_indent = len(line) - len(stripped)
        next_index = index + 1
        while next_index < len(lines) and (not lines[next_index].strip() or lines[next_index].lstrip().startswith("#")):
            next_index += 1
        if next_index >= len(lines):
            check(False, f"{source.relative_to(ROOT)} opens a block without a body at line {index + 1}")
            continue
        next_line = lines[next_index]
        next_indent = len(next_line) - len(next_line.lstrip("\t "))
        check(next_indent > current_indent,
              f"{source.relative_to(ROOT)} block body is not indented at line {next_index + 1} (opened at {index + 1})")

if errors:
    print(f"FAILED: {len(errors)} issue(s) across {checks} checks")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print(f"PASS: {checks} structural checks; required files, references, catalogs and workflow YAML look consistent.")
print("NOTE: this validator does not parse GDScript or build/run Godot. CI performs those checks using Godot.")
